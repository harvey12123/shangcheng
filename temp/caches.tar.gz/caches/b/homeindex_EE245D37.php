<?php exit;?>a:3:{s:8:"template";a:4:{i:0;s:54:"/www/site/demo/zz/themes/ecmoban_dsc2017/homeindex.dwt";i:1;s:69:"/www/site/demo/zz/themes/ecmoban_dsc2017/library/js_languages_new.lbi";i:2;s:71:"/www/site/demo/zz/themes/ecmoban_dsc2017/library/page_header_common.lbi";i:3;s:64:"/www/site/demo/zz/themes/ecmoban_dsc2017/library/page_footer.lbi";}s:7:"expires";i:1585403019;s:8:"maketime";i:1585399419;}<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Keywords" content="首页" />
<meta name="Description" content="首页" />
<title>首页</title>
<link rel="shortcut icon" href="favicon.ico" />
<link rel="stylesheet" type="text/css" href="themes/ecmoban_dsc2017/css/base.css" />
<link rel="stylesheet" type="text/css" href="themes/ecmoban_dsc2017/css/style.css" />
<link rel="stylesheet" type="text/css" href="themes/ecmoban_dsc2017/css/iconfont.css" />
<link rel="stylesheet" type="text/css" href="themes/ecmoban_dsc2017/css/purebox.css" />
<link rel="stylesheet" type="text/css" href="themes/ecmoban_dsc2017/css/quickLinks.css" />
<script type="text/javascript" src="js/jquery-1.9.1.min.js"></script><script type="text/javascript" src="js/jquery.json.js"></script><script type="text/javascript" src="js/transport_jquery.js"></script>
<script type="text/javascript">
var json_languages = {"ok":"\u786e\u5b9a","determine":"\u786e\u5b9a","cancel":"\u53d6\u6d88","drop":"\u5220\u9664","edit":"\u7f16\u8f91","remove":"\u79fb\u9664","follow":"\u5173\u6ce8","pb_title":"\u63d0\u793a","Prompt_information":"\u63d0\u793a\u4fe1\u606f","title":"\u63d0\u793a","not_login":"\u60a8\u5c1a\u672a\u767b\u5f55","close":"\u5173\u95ed","cart":"\u8d2d\u7269\u8f66","js_cart":"\u8d2d\u7269\u8f66","all":"\u5168\u90e8","go_login":"\u53bb\u767b\u9646","select_city":"\u8bf7\u9009\u62e9\u5e02","comment_goods":"\u8bc4\u8bba\u5546\u54c1","submit_order":"\u63d0\u4ea4\u8ba2\u5355","sys_msg":"\u7cfb\u7edf\u63d0\u793a","no_keywords":"\u8bf7\u8f93\u5165\u641c\u7d22\u5173\u952e\u8bcd\uff01","adv_packup_one":"\u8bf7\u53bb\u540e\u53f0\u5e7f\u544a\u4f4d\u7f6e","adv_packup_two":"\u91cc\u9762\u8bbe\u7f6e\u5e7f\u544a\uff01","more":"\u66f4\u591a","Please":"\u8bf7\u53bb","set_up":"\u8bbe\u7f6e\uff01","login_phone_packup_one":"\u8bf7\u8f93\u5165\u624b\u673a\u53f7\u7801","more_options":"\u66f4\u591a\u9009\u9879","Pack_up":"\u6536\u8d77","no_attr":"\u6ca1\u6709\u66f4\u591a\u5c5e\u6027\u4e86","search_Prompt":"\u53ef\u8f93\u5165\u6c49\u5b57,\u62fc\u97f3\u67e5\u627e\u54c1\u724c","most_input":"\u6700\u591a\u53ea\u80fd\u9009\u62e95\u9879","multi_select":"\u591a\u9009","checkbox_Packup":"\u8bf7\u6536\u8d77\u5168\u90e8\u591a\u9009","radio_Packup":"\u8bf7\u6536\u8d77\u5168\u90e8\u5355\u9009","contrast":"\u5bf9\u6bd4","empty_contrast":"\u6e05\u7a7a\u5bf9\u6bd4\u680f","Prompt_add_one":"\u6700\u591a\u53ea\u80fd\u6dfb\u52a04\u4e2a\u54e6^_^","Prompt_add_two":"\u60a8\u8fd8\u53ef\u4ee5\u7ee7\u7eed\u6dfb\u52a0","button_compare":"\u6bd4\u8f83\u9009\u5b9a\u5546\u54c1","exist":"\u60a8\u5df2\u7ecf\u9009\u62e9\u4e86%s","count_limit":"\u6700\u591a\u53ea\u80fd\u9009\u62e94\u4e2a\u5546\u54c1\u8fdb\u884c\u5bf9\u6bd4","goods_type_different":"%s\u548c\u5df2\u9009\u62e9\u5546\u54c1\u7c7b\u578b\u4e0d\u540c\u65e0\u6cd5\u8fdb\u884c\u5bf9\u6bd4","compare_no_goods":"\u60a8\u6ca1\u6709\u9009\u5b9a\u4efb\u4f55\u9700\u8981\u6bd4\u8f83\u7684\u5546\u54c1\u6216\u8005\u6bd4\u8f83\u7684\u5546\u54c1\u6570\u5c11\u4e8e 2 \u4e2a\u3002","btn_buy":"\u8d2d\u4e70","is_cancel":"\u53d6\u6d88","select_spe":"\u8bf7\u9009\u62e9\u5546\u54c1\u5c5e\u6027","Country":"\u8bf7\u9009\u62e9\u6240\u5728\u56fd\u5bb6","Province":"\u8bf7\u9009\u62e9\u6240\u5728\u7701\u4efd","City":"\u8bf7\u9009\u62e9\u6240\u5728\u5e02","District":"\u8bf7\u9009\u62e9\u6240\u5728\u533a\u57df","Street":"\u8bf7\u9009\u62e9\u6240\u5728\u8857\u9053","Detailed_address_null":"\u8be6\u7ec6\u5730\u5740\u4e0d\u80fd\u4e3a\u7a7a","consignee":"\u8bf7\u586b\u5199\u6536\u8d27\u4eba\u4fe1\u606f","Select_attr":"\u8bf7\u9009\u62e9\u5c5e\u6027","Focus_prompt_one":"\u60a8\u5df2\u5173\u6ce8\u8be5\u5e97\u94fa\uff01","Focus_prompt_login":"\u60a8\u5c1a\u672a\u767b\u5f55\u5546\u57ce\u4f1a\u5458\uff0c\u4e0d\u80fd\u5173\u6ce8\uff01","Focus_prompt_two":"\u767b\u5f55\u5546\u57ce\u4f1a\u5458\u3002","store_focus":"\u5e97\u94fa\u5173\u6ce8\u3002","Focus_prompt_three":"\u60a8\u786e\u5b9e\u8981\u5173\u6ce8\u6240\u9009\u5e97\u94fa\u5417\uff1f","Focus_prompt_four":"\u60a8\u786e\u5b9e\u8981\u53d6\u6d88\u5173\u6ce8\u5e97\u94fa\u5417\uff1f","Focus_prompt_five":"\u60a8\u8981\u5173\u6ce8\u8be5\u5e97\u94fa\u5417\uff1f","Purchase_quantity":"\u8d85\u8fc7\u9650\u8d2d\u6570\u91cf.","My_collection":"\u6211\u7684\u6536\u85cf","shiping_prompt":"\u6682\u4e0d\u652f\u6301\u914d\u9001","Have_goods":"\u6709\u8d27","No_goods":"\u65e0\u8d27","No_shipping":"\u65e0\u6cd5\u914d\u9001","Deliver_back_order":"\u4e0b\u5355\u540e\u7acb\u5373\u53d1\u8d27","Time_delivery":" \u65f6\u53d1\u8d27","goods_over":"\u6b64\u5546\u54c1\u6682\u65f6\u552e\u5b8c","Stock_goods_null":"\u5546\u54c1\u5e93\u5b58\u4e0d\u8db3","purchasing_prompt_two":"\u5bf9\u4e0d\u8d77\uff0c\u8be5\u5546\u54c1\u5df2\u7ecf\u7d2f\u8ba1\u8d85\u8fc7\u9650\u8d2d\u6570\u91cf","day_not_available":"\u5f53\u65e5\u65e0\u8d27","day_yes_available":"\u5f53\u65e5\u6709\u8d27","Already_buy":"\u5df2\u8d2d\u4e70","Already_buy_two":"\u4ef6\u5546\u54c1\u8fbe\u5230\u9650\u8d2d\u6761\u4ef6,\u65e0\u6cd5\u518d\u8d2d\u4e70","Already_buy_three":"\u4ef6\u8be5\u5546\u54c1,\u53ea\u80fd\u518d\u8d2d\u4e70","goods_buy_empty_p":"\u5546\u54c1\u6570\u91cf\u4e0d\u80fd\u5c11\u4e8e1\u4ef6","goods_number_p":"\u5546\u54c1\u6570\u91cf\u5fc5\u987b\u4e3a\u6570\u5b57","search_one":"\u8bf7\u586b\u5199\u7b5b\u9009\u4ef7\u683c","search_two":"\u8bf7\u586b\u5199\u7b5b\u9009\u5de6\u8fb9\u4ef7\u683c","search_three":"\u8bf7\u586b\u5199\u7b5b\u9009\u53f3\u8fb9\u4ef7\u683c","search_four":"\u5de6\u8fb9\u4ef7\u683c\u4e0d\u80fd\u5927\u4e8e\u6216\u7b49\u4e8e\u53f3\u8fb9\u4ef7\u683c","jian":"\u4ef6","letter":"\u4ef6","inventory":"\u5b58\u8d27","move_collection":"\u79fb\u81f3\u6211\u7684\u6536\u85cf","select_shop":"\u8bf7\u9009\u62e9\u5957\u9910\u5546\u54c1","Parameter_error":"\u53c2\u6570\u9519\u8bef","screen_price":"\u8bf7\u586b\u5199\u7b5b\u9009\u4ef7\u683c","screen_price_left":"\u8bf7\u586b\u5199\u7b5b\u9009\u5de6\u8fb9\u4ef7\u683c","screen_price_right":"\u8bf7\u586b\u5199\u7b5b\u9009\u53f3\u8fb9\u4ef7\u683c","screen_price_dy":"\u5de6\u8fb9\u4ef7\u683c\u4e0d\u80fd\u5927\u4e8e\u6216\u7b49\u4e8e\u53f3\u8fb9\u4ef7\u683c","invoice_ok":"\u4fdd\u5b58\u53d1\u7968\u4fe1\u606f","invoice_desc_null":"\u8f93\u5165\u5185\u5bb9\u4e0d\u80fd\u4e3a\u7a7a\uff01","invoice_desc_number":"\u60a8\u6700\u591a\u53ef\u4ee5\u6dfb\u52a03\u4e2a\u516c\u53f8\u53d1\u7968\uff01","invoice_packup":"\u8bf7\u9009\u62e9\u6216\u586b\u5199\u53d1\u7968\u62ac\u5934\u90e8\u5206\uff01","invoice_tax_null":"\u8bf7\u586b\u5199\u7eb3\u7a0e\u4eba\u8bc6\u522b\u7801","add_address_10":"\u6700\u591a\u53ea\u80fd\u6dfb\u52a010\u4e2a\u6536\u8d27\u5730\u5740","msg_phone_not":"\u624b\u673a\u53f7\u7801\u4e0d\u6b63\u786e","msg_phone_blank":"\u624b\u673a\u53f7\u7801\u4e0d\u80fd\u4e3a\u7a7a","captcha_not":"\u9a8c\u8bc1\u7801\u4e0d\u80fd\u4e3a\u7a7a","captcha_xz":"\u8bf7\u8f93\u51654\u4f4d\u6570\u7684\u9a8c\u8bc1\u7801","captcha_cw":"\u9a8c\u8bc1\u7801\u9519\u8bef","Detailed_map":"\u8be6\u7ec6\u5730\u56fe","email_error":"\u90ae\u7bb1\u683c\u5f0f\u4e0d\u6b63\u786e\uff01","bid_prompt_null":"\u4ef7\u683c\u4e0d\u80fd\u4e3a\u7a7a!","bid_prompt_error":"\u4ef7\u683c\u8f93\u5165\u683c\u5f0f\u4e0d\u6b63\u786e\uff01","mobile_error_goods":"\u624b\u673a\u683c\u5f0f\u4e0d\u6b63\u786e\uff01","null_email_goods":"\u90ae\u7bb1\u4e0d\u80fd\u4e3a\u7a7a","select_store":"\u8bf7\u9009\u62e9\u95e8\u5e97\uff01","Product_spec_prompt":"\u8bf7\u9009\u62e9\u5546\u54c1\u89c4\u683c\u7c7b\u578b","reply_desc_one":"\u56de\u590d\u5e16\u5b50\u5185\u5bb9\u4e0d\u80fd\u4e3a\u7a7a","go_shoping":"\u53bb\u8d2d\u7269","loading":"\u6b63\u5728\u62fc\u547d\u52a0\u8f7d\u4e2d...","purchasing_minamount":"\u5bf9\u4e0d\u8d77\uff0c\u8d2d\u4e70\u6570\u91cf\u4e0d\u80fd\u5c0f\u4e8e\u6700\u5c0f\u9636\u68af\u4ef7","no_history":"\u60a8\u5df2\u6e05\u7a7a\u6700\u8fd1\u6d4f\u89c8\u8fc7\u7684\u5546\u54c1","emailInfo_incompleted":"\u60a8\u7684\u90ae\u7bb1\u4fe1\u606f\u672a\u8ba4\u8bc1\uff0c\u8fdb\u5165\u7528\u6237\u4e2d\u5fc3<a href='user.php?act=profile' class='red' target='_blank'>\u5b8c\u5584\u90ae\u7bb1\u4fe1\u606f<\/a>","receive_coupons":"\u9886\u53d6\u4f18\u60e0\u5238","Immediate_use":"\u7acb\u5373\u4f7f\u7528","no_enabled":"\u5173\u95ed","highest_price":"\u5df2\u662f\u6700\u9ad8\u4ef7\uff01","lowest_price":"\u5df2\u662f\u6700\u4f4e\u4ef7\uff01"};
//加载效果
var load_cart_info = '<img src="themes/ecmoban_dsc2017/images/load/loadGoods.gif" class="load" />';
var load_icon = '<img src="themes/ecmoban_dsc2017/images/load/load.gif" width="200" height="200" />';
</script><link rel="stylesheet" type="text/css" href="themes/ecmoban_dsc2017/css/color.css">
</head>
<body class="home_visual_body">
		
        <div class="top-banner" style="background: rgb(255, 40, 125) none repeat scroll 0% 0%;">
            <div class="module w1200" data-type="range">
 
	    <a href="#" target="_blank"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985021864887905.jpg" width="1200" height="80"></a>
    <i class="iconfont icon-cha" ectype="close"></i>
    
</div><div class="spec" data-spec="{&quot;picHeight&quot;:&quot;500&quot;,&quot;target&quot;:&quot;_blank&quot;,&quot;navColor&quot;:&quot;#ff287d&quot;,&quot;is_li&quot;:0,&quot;bg_color&quot;:[],&quot;pic_src&quot;:[&quot;http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985021864887905.jpg&quot;],&quot;link&quot;:&quot;&quot;,&quot;sort&quot;:[&quot;1&quot;]}"></div>
        </div>
        
    <div class="site-nav" id="site-nav">
    <div class="w w1200">
        <div class="fl">
			554fcae493e564ee0dc75bdf2ebf94caheader_region|a:1:{s:4:"name";s:13:"header_region";}554fcae493e564ee0dc75bdf2ebf94ca            <div class="txt-info" id="ECS_MEMBERZONE">
				554fcae493e564ee0dc75bdf2ebf94camember_info|a:1:{s:4:"name";s:11:"member_info";}554fcae493e564ee0dc75bdf2ebf94ca	
            </div>
        </div>
        <ul class="quick-menu fr">
                                                <li>
                <div class="dt"><a href="user.php?act=order_list" >我的订单</a></div>
            </li>
            <li class="spacer"></li>
                                                <li>
                <div class="dt"><a href="history_list.php" >我的浏览</a></div>
            </li>
            <li class="spacer"></li>
                                                <li>
                <div class="dt"><a href="user.php?act=collection_list" >我的收藏</a></div>
            </li>
            <li class="spacer"></li>
                                                <li>
                <div class="dt"><a href="user.php?act=message_list" >客户服务</a></div>
            </li>
            <li class="spacer"></li>
                                                                                                                                                                                                                                    <li class="li_dorpdown" data-ectype="dorpdown">
                <div class="dt dsc-cm">网站导航<i class="iconfont icon-down"></i></div>
                <div class="dd dorpdown-layer">
                    <dl class="fore1">
                        <dt>特色主题</dt>
                        <dd>
                                                                                                <div class="item"><a href="category.php?id=858" target="_blank">家用电器</a></div>
                                                                                                                                <div class="item"><a href="category.php?id=3" target="_blank">手机数码</a></div>
                                                                                                                                <div class="item"><a href="category.php?id=4" target="_blank">电脑办公</a></div>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                </dd>
                    </dl>
                    <dl class="fore2">
                        <dt>促销活动</dt>
                        <dd>
                                                                                                                                                                                                                                                                                                                                                <div class="item"><a href="auction.php">拍卖活动</a></div>
                                                                                                                                <div class="item"><a href="crowdfunding.php">共创商品</a></div>
                                                                                                                                <div class="item"><a href="activity.php">优惠活动</a></div>
                                                                                                                                <div class="item"><a href="wholesale.php">批发市场</a></div>
                                                                                                                                <div class="item"><a href="package.php">超值礼包</a></div>
                                                                                                                                <div class="item"><a href="coupons.php?act=coupons_index">优惠券</a></div>
                                                                                                                                <div class="item"><a href="gift_gard.php">提货中心</a></div>
                                                                                    </dd>
                    </dl>
                </div>
            </li>
                    </ul>
    </div>
</div>
<div class="header">
    <div class="w w1200">
        <div class="logo">
            <div class="logoImg"><a href="index.php"><img src="../themes/ecmoban_dsc2017/images/logo.gif" /></a></div>
						<div class="logoAdv"><a href="merchants.php"><img src="themes/ecmoban_dsc2017/images/ecsc-join.gif" /></a></div>
			        </div>
        <div class="dsc-search">
            <div class="form">
                <form id="searchForm" name="searchForm" method="get" action="search.php" onSubmit="return checkSearchForm(this)" class="search-form">
                    <input autocomplete="off" onKeyUp="lookup(this.value);" name="keywords" type="text" id="keyword" value="554fcae493e564ee0dc75bdf2ebf94carand_keyword|a:1:{s:4:"name";s:12:"rand_keyword";}554fcae493e564ee0dc75bdf2ebf94ca" class="search-text"/>
                                        <input type="hidden" name="store_search_cmt" value="0">
                    <button type="submit" class="button button-goods" onclick="checkstore_search_cmt(0)">搜商品</button>
                    <button type="submit" class="button button-store" onclick="checkstore_search_cmt(1)">搜店铺</button>
                                    </form>
                                <ul class="keyword">
                                <li><a href="search.php?keywords=%E7%89%B9%E8%89%B2" target="_blank">特色</a></li>
                                <li><a href="search.php?keywords=%E7%89%B9%E4%BA%A7" target="_blank">特产</a></li>
                                <li><a href="search.php?keywords=%E7%A4%BC%E5%93%81" target="_blank">礼品</a></li>
                                <li><a href="search.php?keywords=%E7%BA%AA%E5%BF%B5%E5%93%81" target="_blank">纪念品</a></li>
                                <li><a href="search.php?keywords=%E7%BE%8E%E9%A3%9F" target="_blank">美食</a></li>
                                </ul>
                                
                <div class="suggestions_box" id="suggestions" style="display:none;">
                    <div class="suggestions_list" id="auto_suggestions_list">
                        &nbsp;
                    </div>
                </div>
                
            </div>
        </div>
        <div class="shopCart" data-ectype="dorpdown" id="ECS_CARTINFO" data-carteveval="0">
        554fcae493e564ee0dc75bdf2ebf94cacart_info|a:1:{s:4:"name";s:9:"cart_info";}554fcae493e564ee0dc75bdf2ebf94ca        </div>
    </div>
</div>
<div class="nav" ectype="dscNav">
    <div class="w w1200">
        <div class="categorys ">
            <div class="categorys-type"><a href="categoryall.php" target="_blank">全部商品分类</a></div>
            <div class="categorys-tab-content">
            	554fcae493e564ee0dc75bdf2ebf94cacategory_tree_nav|a:3:{s:4:"name";s:17:"category_tree_nav";s:9:"cat_model";s:1:"0";s:7:"cat_num";i:7;}554fcae493e564ee0dc75bdf2ebf94ca            </div>
        </div>
                <div class="nav-main" id="nav">
            <ul class="navitems">
                <li><a href="index.php" class="curr">首页</a></li>
                                <li><a href="category.php?id=12"  >食品特产</a></li>
                                <li><a href="category.php?id=6"  >服装城</a></li>
                                <li><a href="category.php?id=858"  >大家电</a></li>
                                <li><a href="category.php?id=8"  >鞋靴箱包</a></li>
                                <li><a href="brand.php"  >品牌专区</a></li>
                                <li><a href="group_buy.php"  >聚划算</a></li>
                                <li><a href="exchange.php"  >积分商城</a></li>
                                <li><a href="presale.php"  >预售</a></li>
                                <li><a href="store_street.php"  >店铺街</a></li>
                            </ul>
        </div>
            </div>
</div>
        <div class="homeindex" ectype="homeWrap">
    	
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                        
<div class="content" style="min-height: 922px;"><div class="visual-item" data-mode="lunbo" data-purebox="banner" data-li="1" data-length="5" ectype="visualItme" style="display: block;" data-diff="0">
                                    
                                    <div class="view">
                                        <div class="banner home-banner">
                                        	<div class="bd">
                                            	<ul data-type="range">
 
	    <li style="background:url(http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984992503176615.jpg) center center no-repeat;"><div class="banner-width"><a href="" style="height:500px;"></a></div></li>
    	    <li style="background:url(http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984990506843460.jpg) center center no-repeat;"><div class="banner-width"><a href="" style="height:500px;"></a></div></li>
    	    <li style="background:url(http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984991783527346.jpg) center center no-repeat;"><div class="banner-width"><a href="" style="height:500px;"></a></div></li>
    
</ul><div class="spec" data-spec=""></div>
                                            </div>
                                            <div class="hd"><ul></ul></div>
                                            <div class="vip-outcon">
                                                <div class="vip-con">
                                                    <div class="insertVipEdit" data-mode="insertVipEdit">
 
<div ectype="user_info">
    <div class="avatar">
        <a href="user.php?act=profile"><img src="http://demo.zz.jabrielcloud.com/images/avatar.png"></a>
    </div>
    <div class="login-info">
        <span>Hi，欢迎来到文旅新零售平台</span>
        <a href="user.php" class="login-button">请登录</a>
        <a href="merchants.php" target="_blank" class="register_button">我要开店</a>
    </div>
</div>   
<div class="vip-item">
    <div class="tit">
                <a href="javascript:void(0);" class="tab_head_item">公告</a>
                <a href="javascript:void(0);" class="tab_head_item">促销</a>
            </div>
    <div class="con">
                <ul>
                        <li><a href="article.php?id=63" target="_blank">服务店突破2000多家</a></li>
                        <li><a href="article.php?id=62" target="_blank">我们成为中国最大家电零售B2B2C系统</a></li>
                        <li><a href="article.php?id=61" target="_blank">三大国际腕表品牌签约</a></li>
                    </ul>
                <ul style="display:none;">
                        <li><a href="article.php?id=60" target="_blank">春季家装季，家电买一送一</a></li>
                        <li><a href="article.php?id=59" target="_blank">抢百元优惠券，享4.22%活期</a></li>
                        <li><a href="article.php?id=58" target="_blank">Macbook最高返50000消费豆！</a></li>
                    </ul>
            </div>
</div>
<div class="vip-item">
    <div class="tit">快捷入口</div>
    <div class="kj_con">
                        <div class="item item_1">
            <a href="history_list.php" target="_blank">
                <i class="iconfont icon-browse"></i>
                <span>我的浏览</span>
            </a>
        </div>
                                <div class="item item_2">
            <a href="user.php?act=collection_list" target="_blank">
                <i class="iconfont icon-zan-alt"></i>
                <span>我的收藏</span>
            </a>
        </div>
                                <div class="item item_3">
            <a href="user.php?act=order_list" target="_blank">
                <i class="iconfont icon-order"></i>
                <span>我的订单</span>
            </a>
        </div>
                                <div class="item item_4">
            <a href="user.php?act=account_safe" target="_blank">
                <i class="iconfont icon-password-alt"></i>
                <span>账号安全</span>
            </a>
        </div>
                                <div class="item item_5">
            <a href="user.php?act=affiliate" target="_blank">
                <i class="iconfont icon-share-alt"></i>
                <span>我要分享</span>
            </a>
        </div>
                                <div class="item item_6">
            <a href="merchants.php" target="_blank">
                <i class="iconfont icon-settled"></i>
                <span>商家入驻</span>
            </a>
        </div>
                    </div>
</div>
</div><div class="spec" data-spec=""></div>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div><div class="visual-item w1200" data-mode="h-need" data-purebox="homeAdv" data-li="1" ectype="visualItme" data-diff="0" style="display: block;">
                                    
                                    <div class="view">
                                        <div class="need-channel clearfix" id="h-need_0" data-type="range" data-lift="推荐">
 
<div class="channel-column" style="background:url(http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984987302153402.jpg) no-repeat;">
    <div class="column-title">
            <h3>优质新品</h3>
        <p>专注生活美学</p>
    </div>
    <div class="column-img"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985002375136884.png"></div>
    <a href="" target="_blank" class="column-btn">去看看</a>
</div>
<div class="channel-column" style="background:url(http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984989930757668.jpg) no-repeat;">
    <div class="column-title">
            <h3>潮流女装</h3>
        <p>春装流行款抢购</p>
    </div>
    <div class="column-img"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984989766362152.png"></div>
    <a href="" target="_blank" class="column-btn">去看看</a>
</div>
<div class="channel-column" style="background:url(http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984989391013089.jpg) no-repeat;">
    <div class="column-title">
            <h3>人气美鞋</h3>
        <p>新外貌“鞋”会</p>
    </div>
    <div class="column-img"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984990383161028.png"></div>
    <a href="" target="_blank" class="column-btn">去看看</a>
</div>
<div class="channel-column" style="background:url(http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984987606903394.jpg) no-repeat;">
    <div class="column-title">
            <h3>品牌精选</h3>
        <p>潮牌尖货 初春换新</p>
    </div>
    <div class="column-img"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984988032635434.png"></div>
    <a href="" target="_blank" class="column-btn">去看看</a>
</div>
<div class="channel-column" style="background:url(http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984990175755536.jpg) no-repeat;">
    <div class="column-title">
            <h3>护肤彩妆</h3>
        <p>春妆必买清单 低至3折</p>
    </div>
    <div class="column-img"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984991251825734.png"></div>
    <a href="" target="_blank" class="column-btn">去看看</a>
</div>
<div class="spec" data-spec="" data-title=""></div></div>
                                    </div>
                                </div><div class="visual-item w1200 brandList" data-mode="h-brand" data-purebox="homeAdv" data-li="1" ectype="visualItme" data-diff="0" style="display: block;">
                                    
                                    <div class="view">
                                        <div class="brand-channel clearfix" id="h-brand_0" data-type="range" data-lift="品牌">
 
<div class="home-brand-adv slide_lr_info">
        <a href="" target="_blank"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984992104112514.jpg" class="slide_lr_img"></a>
    </div>
<div ectype="homeBrand">
    <div class="brand-list" id="recommend_brands" data-value="204,93,110,113,116,195,79,95,76,126,73,122,98,82,101,85,105">
        <ul>
                        <li>
                <div class="brand-img"><a href="brandn.php?id=204" target="_blank"><img src="data/brandlogo/1490039286075654490.jpg"></a></div>
                <div class="brand-mash">
                    <div data-bid="204" ectype="coll_brand"><i class="iconfont icon-zan-alt"></i></div>
                    <div class="coupon"><a href="brandn.php?id=204" target="_blank">关注人数<br><div id="collect_count_204">0</div></a></div>
                </div>
            </li>
                        <li>
                <div class="brand-img"><a href="brandn.php?id=195" target="_blank"><img src="data/brandlogo/1490075385239594909.jpg"></a></div>
                <div class="brand-mash">
                    <div data-bid="195" ectype="coll_brand"><i class="iconfont icon-zan-alt"></i></div>
                    <div class="coupon"><a href="brandn.php?id=195" target="_blank">关注人数<br><div id="collect_count_195">0</div></a></div>
                </div>
            </li>
                        <li>
                <div class="brand-img"><a href="brandn.php?id=73" target="_blank"><img src="data/brandlogo/1490072329183966195.jpg"></a></div>
                <div class="brand-mash">
                    <div data-bid="73" ectype="coll_brand"><i class="iconfont icon-zan-alt"></i></div>
                    <div class="coupon"><a href="brandn.php?id=73" target="_blank">关注人数<br><div id="collect_count_73">0</div></a></div>
                </div>
            </li>
                        <li>
                <div class="brand-img"><a href="brandn.php?id=76" target="_blank"><img src="data/brandlogo/1490072373278367315.jpg"></a></div>
                <div class="brand-mash">
                    <div data-bid="76" ectype="coll_brand"><i class="iconfont icon-zan-alt"></i></div>
                    <div class="coupon"><a href="brandn.php?id=76" target="_blank">关注人数<br><div id="collect_count_76">0</div></a></div>
                </div>
            </li>
                        <li>
                <div class="brand-img"><a href="brandn.php?id=79" target="_blank"><img src="data/brandlogo/1490072677495061584.jpg"></a></div>
                <div class="brand-mash">
                    <div data-bid="79" ectype="coll_brand"><i class="iconfont icon-zan-alt"></i></div>
                    <div class="coupon"><a href="brandn.php?id=79" target="_blank">关注人数<br><div id="collect_count_79">0</div></a></div>
                </div>
            </li>
                        <li>
                <div class="brand-img"><a href="brandn.php?id=82" target="_blank"><img src="data/brandlogo/1490072694695600078.jpg"></a></div>
                <div class="brand-mash">
                    <div data-bid="82" ectype="coll_brand"><i class="iconfont icon-zan-alt"></i></div>
                    <div class="coupon"><a href="brandn.php?id=82" target="_blank">关注人数<br><div id="collect_count_82">0</div></a></div>
                </div>
            </li>
                        <li>
                <div class="brand-img"><a href="brandn.php?id=85" target="_blank"><img src="data/brandlogo/1490072756032175204.jpg"></a></div>
                <div class="brand-mash">
                    <div data-bid="85" ectype="coll_brand"><i class="iconfont icon-zan-alt"></i></div>
                    <div class="coupon"><a href="brandn.php?id=85" target="_blank">关注人数<br><div id="collect_count_85">0</div></a></div>
                </div>
            </li>
                        <li>
                <div class="brand-img"><a href="brandn.php?id=110" target="_blank"><img src="data/brandlogo/1490074043963552715.jpg"></a></div>
                <div class="brand-mash">
                    <div data-bid="110" ectype="coll_brand"><i class="iconfont icon-zan-alt"></i></div>
                    <div class="coupon"><a href="brandn.php?id=110" target="_blank">关注人数<br><div id="collect_count_110">0</div></a></div>
                </div>
            </li>
                        <li>
                <div class="brand-img"><a href="brandn.php?id=113" target="_blank"><img src="data/brandlogo/1490074030328949587.jpg"></a></div>
                <div class="brand-mash">
                    <div data-bid="113" ectype="coll_brand"><i class="iconfont icon-zan-alt"></i></div>
                    <div class="coupon"><a href="brandn.php?id=113" target="_blank">关注人数<br><div id="collect_count_113">0</div></a></div>
                </div>
            </li>
                        <li>
                <div class="brand-img"><a href="brandn.php?id=116" target="_blank"><img src="data/brandlogo/1490073109529817869.jpg"></a></div>
                <div class="brand-mash">
                    <div data-bid="116" ectype="coll_brand"><i class="iconfont icon-zan-alt"></i></div>
                    <div class="coupon"><a href="brandn.php?id=116" target="_blank">关注人数<br><div id="collect_count_116">0</div></a></div>
                </div>
            </li>
                        <li>
                <div class="brand-img"><a href="brandn.php?id=122" target="_blank"><img src="data/brandlogo/1490073982547710498.jpg"></a></div>
                <div class="brand-mash">
                    <div data-bid="122" ectype="coll_brand"><i class="iconfont icon-zan-alt"></i></div>
                    <div class="coupon"><a href="brandn.php?id=122" target="_blank">关注人数<br><div id="collect_count_122">0</div></a></div>
                </div>
            </li>
                        <li>
                <div class="brand-img"><a href="brandn.php?id=126" target="_blank"><img src="data/brandlogo/1490073943918274561.jpg"></a></div>
                <div class="brand-mash">
                    <div data-bid="126" ectype="coll_brand"><i class="iconfont icon-zan-alt"></i></div>
                    <div class="coupon"><a href="brandn.php?id=126" target="_blank">关注人数<br><div id="collect_count_126">0</div></a></div>
                </div>
            </li>
                        <li>
                <div class="brand-img"><a href="brandn.php?id=95" target="_blank"><img src="data/brandlogo/1490072870537181142.jpg"></a></div>
                <div class="brand-mash">
                    <div data-bid="95" ectype="coll_brand"><i class="iconfont icon-zan-alt"></i></div>
                    <div class="coupon"><a href="brandn.php?id=95" target="_blank">关注人数<br><div id="collect_count_95">0</div></a></div>
                </div>
            </li>
                        <li>
                <div class="brand-img"><a href="brandn.php?id=98" target="_blank"><img src="data/brandlogo/1490072898345358625.jpg"></a></div>
                <div class="brand-mash">
                    <div data-bid="98" ectype="coll_brand"><i class="iconfont icon-zan-alt"></i></div>
                    <div class="coupon"><a href="brandn.php?id=98" target="_blank">关注人数<br><div id="collect_count_98">0</div></a></div>
                </div>
            </li>
                        <li>
                <div class="brand-img"><a href="brandn.php?id=101" target="_blank"><img src="data/brandlogo/1490072931218635674.jpg"></a></div>
                <div class="brand-mash">
                    <div data-bid="101" ectype="coll_brand"><i class="iconfont icon-zan-alt"></i></div>
                    <div class="coupon"><a href="brandn.php?id=101" target="_blank">关注人数<br><div id="collect_count_101">0</div></a></div>
                </div>
            </li>
                        <li>
                <div class="brand-img"><a href="brandn.php?id=105" target="_blank"><img src="data/brandlogo/1490072971610241726.jpg"></a></div>
                <div class="brand-mash">
                    <div data-bid="105" ectype="coll_brand"><i class="iconfont icon-zan-alt"></i></div>
                    <div class="coupon"><a href="brandn.php?id=105" target="_blank">关注人数<br><div id="collect_count_105">0</div></a></div>
                </div>
            </li>
                        <li>
                <div class="brand-img"><a href="brandn.php?id=93" target="_blank"><img src="data/brandlogo/1490072850306019115.jpg"></a></div>
                <div class="brand-mash">
                    <div data-bid="93" ectype="coll_brand"><i class="iconfont icon-zan-alt"></i></div>
                    <div class="coupon"><a href="brandn.php?id=93" target="_blank">关注人数<br><div id="collect_count_93">0</div></a></div>
                </div>
            </li>
                    </ul>
        <a href="javascript:void(0);" ectype="changeBrand" class="refresh-btn"><i class="iconfont icon-rotate-alt"></i><span>换一批</span></a>
    </div>
</div>
<div class="spec" data-spec="" data-title="undefined"></div></div>
                                    </div>
                                </div><div class="visual-item w1200" data-mode="homeFloor" data-purebox="homeFloor" data-li="1" ectype="visualItme" data-diff="1" style="display: block; position: relative; opacity: 1; left: 0px; top: 0px;">
                                    
                                    <div class="view">
                                        <div class="floor-content" data-type="range" id="homeFloor_1" data-lift="女装">
 
<div class="floor-line-con floorOne floor-color-type-1" data-idx="1" id="floor_1" ectype="floorItem">
    <div class="floor-hd" ectype="floorTit">
    	<i class="box_hd_arrow"></i>
    	<i class="box_hd_dec"></i>
        <div class="hd-tit">男装、女装、内衣</div>        <div class="hd-tags">
            <ul>
                <li class="first current">
                    <span>新品推荐</span>
                    <i class="arrowImg"></i>
                </li>
                                                                <li data-catgoods="770,771,772,773,774,775,796,797,798,799,800,801" class="first" ectype="floor_cat_content" data-flooreveval="0" data-visualhome="1" data-floornum="6" data-id="347">
                    <span>女装</span>
                    <i class="arrowImg"></i>
                </li>
                                                                <li data-catgoods="783,782,781,780,779,778,777,707,671" class="first" ectype="floor_cat_content" data-flooreveval="0" data-visualhome="1" data-floornum="6" data-id="630">
                    <span>服饰配件</span>
                    <i class="arrowImg"></i>
                </li>
                                                                <li data-catgoods="795,794,793,792,791,790,632,631,629,628" class="first" ectype="floor_cat_content" data-flooreveval="0" data-visualhome="1" data-floornum="6" data-id="547">
                    <span>内衣</span>
                    <i class="arrowImg"></i>
                </li>
                                                                <li data-catgoods="864,863,865,627,626,625,784,866,789,788,787,786" class="first" ectype="floor_cat_content" data-flooreveval="0" data-visualhome="1" data-floornum="6" data-id="463">
                    <span>男装</span>
                    <i class="arrowImg"></i>
                </li>
                                                            </ul>
        </div>
    </div>
    <div class="floor-bd bd-mode-01">
        <div class="bd-left">
                        <div class="floor-left-slide">
                <div class="bd">
                    <ul>
                                                                        <li><a href=""><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985255003388359.jpg"></a></li>
                                                                                                <li><a href=""><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985255671031591.jpg"></a></li>
                                                                                                <li><a href=""><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985255859372374.jpg"></a></li>
                                                                    </ul>
                </div>
                <div class="hd"><ul></ul></div>
            </div>
                        
            <div class="floor-left-adv">
                                                <a href="" target="_blank"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984993812175408.jpg"></a>
                                                                <a href="" target="_blank"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984993892207941.jpg"></a>
                                            </div>
            
                    </div>
        <div class="bd-right">
            <div class="floor-tabs-content clearfix">
                <div class="f-r-main f-r-m-adv">
                                        <div class="f-r-m-item
                                        	                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>随意搭</h3>
                                <span>满100减100</span>
                            </div>
                            <img src="
                            	                                	                                        http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984997173604814.jpg                                                                                                ">
                        </a>
                    </div>
                                        <div class="f-r-m-item
                                        	                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>外套</h3>
                                <span>来潮我看</span>
                            </div>
                            <img src="
                            	                                	                                        http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985255611006354.png                                                                                                ">
                        </a>
                    </div>
                                        <div class="f-r-m-item
                                        	                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>连衣裙</h3>
                                <span>大牌好货抢</span>
                            </div>
                            <img src="
                            	                                	                                        http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985257076782520.png                                                                                                ">
                        </a>
                    </div>
                                        <div class="f-r-m-item
                                        	                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>女式套装</h3>
                                <span>春季流行款抢购</span>
                            </div>
                            <img src="
                            	                                	                                        http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985261416235695.jpg                                                                                                ">
                        </a>
                    </div>
                                        <div class="f-r-m-item
                                        	 f-r-m-i-double                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>标题广告图</h3>
                                <span>新品低至五折</span>
                            </div>
                            <img src="
                            	                                	                            			http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984998972685382.jpg                                                                                                ">
                        </a>
                    </div>
                                    </div>
                                <div class="f-r-main" ectype="floor_cat_347">
                    <ul class="p-list"></ul>
                </div>
                                <div class="f-r-main" ectype="floor_cat_630">
                    <ul class="p-list"></ul>
                </div>
                                <div class="f-r-main" ectype="floor_cat_547">
                    <ul class="p-list"></ul>
                </div>
                                <div class="f-r-main" ectype="floor_cat_463">
                    <ul class="p-list"></ul>
                </div>
                            </div>
        </div>
    </div>
        <div class="floor-fd">
        <div class="floor-fd-brand clearfix">
                        <div class="item">
                <a href="brandn.php?id=72" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490072313895957648.jpg" title="ELLE HOME"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=76" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490072373278367315.jpg" title="金利来"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=79" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490072677495061584.jpg" title="justyle"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=82" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490072694695600078.jpg" title="李宁"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=86" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490072765604121481.jpg" title="康比特"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=106" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490072981305868823.jpg" title="开普特"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=122" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490073982547710498.jpg" title="Five Plus"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=149" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490073591535005714.jpg" title="鸿星尔克"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=152" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490228100138579787.jpg" title="杰克琼斯"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=154" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490073529881448780.jpg" title="匡威"></div>
                    <div class="link"></div>
                </a>
            </div>
                    </div>
    </div>
    </div>
<div class="spec" data-spec="" data-title="undefined"></div></div>
                                    </div>
                                </div><div class="visual-item w1200" data-mode="homeFloor" data-purebox="homeFloor" data-li="1" ectype="visualItme" data-diff="2" style="display: block; position: relative; opacity: 1; z-index: 0; left: 0px; top: 0px;">
                                    
                                    <div class="view">
                                        <div class="floor-content" data-type="range" id="homeFloor_2" data-lift="鞋靴">
 
<div class="floor-line-con floorOne floor-color-type-2" data-idx="1" id="floor_2" ectype="floorItem">
    <div class="floor-hd" ectype="floorTit">
    	<i class="box_hd_arrow"></i>
    	<i class="box_hd_dec"></i>
        <div class="hd-tit">鞋靴、箱包、钟表、奢侈品</div>        <div class="hd-tags">
            <ul>
                <li class="first current">
                    <span>新品推荐</span>
                    <i class="arrowImg"></i>
                </li>
                                                                <li data-catgoods="682,683,832" class="first" ectype="floor_cat_content" data-flooreveval="0" data-visualhome="1" data-floornum="6" data-id="360">
                    <span>功能箱包</span>
                    <i class="arrowImg"></i>
                </li>
                                                                <li data-catgoods="903,834,685,684" class="first" ectype="floor_cat_content" data-flooreveval="0" data-visualhome="1" data-floornum="6" data-id="355">
                    <span>流行男鞋</span>
                    <i class="arrowImg"></i>
                </li>
                                                                <li data-catgoods="836,837,838,839,840,841" class="first" ectype="floor_cat_content" data-flooreveval="0" data-visualhome="1" data-floornum="6" data-id="362">
                    <span>奢侈品</span>
                    <i class="arrowImg"></i>
                </li>
                                                                <li data-catgoods="681,680,679,676" class="first" ectype="floor_cat_content" data-flooreveval="0" data-visualhome="1" data-floornum="6" data-id="353">
                    <span>时尚女鞋</span>
                    <i class="arrowImg"></i>
                </li>
                                                            </ul>
        </div>
    </div>
    <div class="floor-bd bd-mode-02">
        <div class="bd-left">
                        <div class="floor-left-slide">
                <div class="bd">
                    <ul>
                                                                        <li><a href=""><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984993525657918.jpg"></a></li>
                                                                                                <li><a href=""><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985258163076122.jpg"></a></li>
                                                                                                <li><a href=""><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985258841930385.jpg"></a></li>
                                                                    </ul>
                </div>
                <div class="hd"><ul></ul></div>
            </div>
                        
            <div class="floor-left-adv">
                                                <a href="" target="_blank"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984994714366758.jpg"></a>
                                                                <a href="" target="_blank"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984994759822929.jpg"></a>
                                            </div>
            
                    </div>
        <div class="bd-right">
            <div class="floor-tabs-content clearfix">
                <div class="f-r-main f-r-m-adv">
                                        <div class="f-r-m-item
                                        	 f-r-m-i-double                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>欧时纳女包</h3>
                                <span>磨砂登机箱</span>
                            </div>
                            <img src="
                            	                                	                            			http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985264048620039.jpg                                                                                                ">
                        </a>
                    </div>
                                        <div class="f-r-m-item
                                        	                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>大牌精选</h3>
                                <span>商城自营闪电发货</span>
                            </div>
                            <img src="
                            	                                	                                        http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985259325736762.jpg                                                                                                ">
                        </a>
                    </div>
                                        <div class="f-r-m-item
                                        	                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>防水斜挎包</h3>
                                <span>跨万店三免一</span>
                            </div>
                            <img src="
                            	                                	                                        http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985254984045600.png                                                                                                ">
                        </a>
                    </div>
                                        <div class="f-r-m-item
                                        	                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>纪梵希</h3>
                                <span>满199减100</span>
                            </div>
                            <img src="
                            	                                	                                        http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985261810426955.jpg                                                                                                ">
                        </a>
                    </div>
                                        <div class="f-r-m-item
                                        	                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>标题广告图</h3>
                                <span>大牌上新</span>
                            </div>
                            <img src="
                            	                                	                                        http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1495042209788792159.jpg                                                                                                ">
                        </a>
                    </div>
                                    </div>
                                <div class="f-r-main" ectype="floor_cat_360">
                    <ul class="p-list"></ul>
                </div>
                                <div class="f-r-main" ectype="floor_cat_355">
                    <ul class="p-list"></ul>
                </div>
                                <div class="f-r-main" ectype="floor_cat_362">
                    <ul class="p-list"></ul>
                </div>
                                <div class="f-r-main" ectype="floor_cat_353">
                    <ul class="p-list"></ul>
                </div>
                            </div>
        </div>
    </div>
        <div class="floor-fd">
        <div class="floor-fd-brand clearfix">
                        <div class="item">
                <a href="brandn.php?id=93" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490072850306019115.jpg" title="同庆和堂"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=115" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490074006660107941.jpg" title="西门子"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=130" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490074180745676140.jpg" title="TP-LINL"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=131" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490073919711003101.jpg" title="ZIPPO"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=132" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490073900838296364.jpg" title="阿玛尼"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=138" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490073717776504773.jpg" title="迪士尼"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=139" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490073705755280994.jpg" title="飞科"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=154" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490073529881448780.jpg" title="匡威"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=178" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490073253749057076.jpg" title="文轩网"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=186" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490074308773778697.jpg" title="新百伦"></div>
                    <div class="link"></div>
                </a>
            </div>
                    </div>
    </div>
    </div>
<div class="spec" data-spec="" data-title="undefined"></div></div>
                                    </div>
                                </div><div class="visual-item w1200" data-mode="homeFloor" data-purebox="homeFloor" data-li="1" ectype="visualItme" data-diff="3" style="display: block;">
                                    
                                    <div class="view">
                                        <div class="floor-content" data-type="range" id="homeFloor_3" data-lift="食品">
 
<div class="floor-line-con floorOne floor-color-type-3" data-idx="1" id="floor_3" ectype="floorItem">
    <div class="floor-hd" ectype="floorTit">
    	<i class="box_hd_arrow"></i>
    	<i class="box_hd_dec"></i>
        <div class="hd-tit">食品、酒类、生鲜、特产</div>        <div class="hd-tags">
            <ul>
                <li class="first current">
                    <span>新品推荐</span>
                    <i class="arrowImg"></i>
                </li>
                                                                <li data-catgoods="736,737,738,739,740,741" class="first" ectype="floor_cat_content" data-flooreveval="0" data-visualhome="1" data-floornum="6" data-id="616">
                    <span>进口食品</span>
                    <i class="arrowImg"></i>
                </li>
                                                                <li data-catgoods="759,758,757,756,755,754" class="first" ectype="floor_cat_content" data-flooreveval="0" data-visualhome="1" data-floornum="6" data-id="623">
                    <span>生鲜食品</span>
                    <i class="arrowImg"></i>
                </li>
                                                                <li data-catgoods="760,761,762,763,764,765,766" class="first" ectype="floor_cat_content" data-flooreveval="0" data-visualhome="1" data-floornum="6" data-id="615">
                    <span>中外名酒</span>
                    <i class="arrowImg"></i>
                </li>
                                                                <li data-catgoods="900,899,898,897,896,895" class="first" ectype="floor_cat_content" data-flooreveval="0" data-visualhome="1" data-floornum="6" data-id="622">
                    <span>粮油调味</span>
                    <i class="arrowImg"></i>
                </li>
                                                                <li data-catgoods="747,746,745,744,743,742" class="first" ectype="floor_cat_content" data-flooreveval="0" data-visualhome="1" data-floornum="6" data-id="617">
                    <span>休闲食品</span>
                    <i class="arrowImg"></i>
                </li>
                                                            </ul>
        </div>
    </div>
    <div class="floor-bd bd-mode-03">
        <div class="bd-left">
                        
            <div class="floor-left-adv">
                                                <a href="" target="_blank"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984995376315298.jpg"></a>
                                                                <a href="" target="_blank"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494984995451465490.jpg"></a>
                                            </div>
            
                    </div>
        <div class="bd-right">
            <div class="floor-tabs-content clearfix">
                <div class="f-r-main f-r-m-adv">
                                        <div class="f-r-m-item
                                        	                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>金锣火腿肠</h3>
                                <span>商城自营好物低价</span>
                            </div>
                            <img src="
                            	                                	                                        http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985253313357913.jpg                                                                                                ">
                        </a>
                    </div>
                                        <div class="f-r-m-item
                                        	 f-r-m-i-double                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>酸辣牛肉味五连包</h3>
                                <span>方便食品</span>
                            </div>
                            <img src="
                            	                                	                            			http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985009349965302.jpg                                                                                                ">
                        </a>
                    </div>
                                        <div class="f-r-m-item
                                        	                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>香茉莉香米</h3>
                                <span>五件包399选14</span>
                            </div>
                            <img src="
                            	                                	                                        http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985008433437711.jpg                                                                                                ">
                        </a>
                    </div>
                                        <div class="f-r-m-item
                                        	                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>魔力紫</h3>
                                <span>满76香米1KG</span>
                            </div>
                            <img src="
                            	                                	                                        http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985262035088187.jpg                                                                                                ">
                        </a>
                    </div>
                                        <div class="f-r-m-item
                                        	                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>标题广告图</h3>
                                <span>尽享休闲时光</span>
                            </div>
                            <img src="
                            	                                	                                        http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985264023870581.jpg                                                                                                ">
                        </a>
                    </div>
                                    </div>
                                <div class="f-r-main" ectype="floor_cat_616">
                    <ul class="p-list"></ul>
                </div>
                                <div class="f-r-main" ectype="floor_cat_623">
                    <ul class="p-list"></ul>
                </div>
                                <div class="f-r-main" ectype="floor_cat_615">
                    <ul class="p-list"></ul>
                </div>
                                <div class="f-r-main" ectype="floor_cat_622">
                    <ul class="p-list"></ul>
                </div>
                                <div class="f-r-main" ectype="floor_cat_617">
                    <ul class="p-list"></ul>
                </div>
                            </div>
        </div>
    </div>
        <div class="floor-fd">
        <div class="floor-fd-brand clearfix">
                        <div class="item">
                <a href="brandn.php?id=73" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490072329183966195.jpg" title="她他/tata"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=81" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490072685002270742.jpg" title="宝姿"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=83" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490072728394097278.jpg" title="白兰氏"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=102" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490072941526335126.jpg" title="欧亚马"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=107" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490072993409028193.jpg" title="三星"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=117" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490073123533047769.jpg" title="阿尔卡特"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=130" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490074180745676140.jpg" title="TP-LINL"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=136" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490227517695746097.jpg" title="博时基金"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=137" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490073731822160672.jpg" title="达利园"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=141" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490074990110164877.jpg" title="钙尔奇"></div>
                    <div class="link"></div>
                </a>
            </div>
                    </div>
    </div>
    </div>
<div class="spec" data-spec="" data-title="undefined"></div></div>
                                    </div>
                                </div><div class="visual-item w1200" data-mode="homeFloor" data-purebox="homeFloor" data-li="1" ectype="visualItme" data-diff="4" style="display: block;">
                                    
                                    <div class="view">
                                        <div class="floor-content" data-type="range" id="homeFloor_4" data-lift="家用">
 
<div class="floor-line-con floorOne floor-color-type-4" data-idx="1" id="floor_4" ectype="floorItem">
    <div class="floor-hd" ectype="floorTit">
    	<i class="box_hd_arrow"></i>
    	<i class="box_hd_dec"></i>
        <div class="hd-tit">家用电器</div>        <div class="hd-tags">
            <ul>
                <li class="first current">
                    <span>新品推荐</span>
                    <i class="arrowImg"></i>
                </li>
                                                                <li data-catgoods="692,694,820,821,822,823,824,825,844,845,846,847" class="first" ectype="floor_cat_content" data-flooreveval="0" data-visualhome="1" data-floornum="6" data-id="1115">
                    <span>生活电器</span>
                    <i class="arrowImg"></i>
                </li>
                                                                <li data-catgoods="" class="first" ectype="floor_cat_content" data-flooreveval="0" data-visualhome="1" data-floornum="6" data-id="1129">
                    <span>厨房电器</span>
                    <i class="arrowImg"></i>
                </li>
                                                                <li data-catgoods="856,855,854,853,852,851,819,818,817,816,815,814" class="first" ectype="floor_cat_content" data-flooreveval="0" data-visualhome="1" data-floornum="6" data-id="1145">
                    <span>个护健康</span>
                    <i class="arrowImg"></i>
                </li>
                                                                <li data-catgoods="862,861,860,859,858,857,831,830,829,828,827,826" class="first" ectype="floor_cat_content" data-flooreveval="0" data-visualhome="1" data-floornum="6" data-id="1160">
                    <span>五金家装</span>
                    <i class="arrowImg"></i>
                </li>
                                                            </ul>
        </div>
    </div>
    <div class="floor-bd bd-mode-04">
        <div class="bd-left">
                        
            <div class="floor-left-adv">
                                                <a href="" target="_blank"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985252213529452.jpg"></a>
                                                                <a href="" target="_blank"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985263907218565.jpg"></a>
                                            </div>
            
                        <div class="floor-left-slide">
                <div class="bd">
                    <ul>
                                                <li><a href=""><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985258768732496.jpg"></a></li>
                                                <li><a href=""><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985266144681478.png"></a></li>
                                                <li><a href=""><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985266980557091.png"></a></li>
                                            </ul>
                </div>
                <div class="hd"><ul></ul></div>
            </div>
                    </div>
        <div class="bd-right">
            <div class="floor-tabs-content clearfix">
                <div class="f-r-main f-r-m-adv">
                                        <div class="f-r-m-item
                                        	                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>标题广告图</h3>
                                <span>买既得无线鼠标一个</span>
                            </div>
                            <img src="
                            	                                	                                        http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985010017482916.jpg                                                                                                ">
                        </a>
                    </div>
                                        <div class="f-r-m-item
                                        	                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>海信55英寸</h3>
                                <span>洗化干衣一体</span>
                            </div>
                            <img src="
                            	                                	                                        http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985252050215807.jpg                                                                                                ">
                        </a>
                    </div>
                                        <div class="f-r-m-item
                                        	                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>欧景除湿器</h3>
                                <span>满100减19</span>
                            </div>
                            <img src="
                            	                                	                                        http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985253347581677.JPG                                                                                                ">
                        </a>
                    </div>
                                        <div class="f-r-m-item
                                        	 f-r-m-i-double                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>极客系列</h3>
                                <span>给力实惠</span>
                            </div>
                            <img src="
                            	                                	                            			http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985267962226313.JPG                                                                                                ">
                        </a>
                    </div>
                                        <div class="f-r-m-item
                                        	                    ">
                        <a href="" target="_blank">
                            <div class="title">
                                <h3>智能音箱</h3>
                                <span>定金100减300</span>
                            </div>
                            <img src="
                            	                                	                                        http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985260469428998.jpg                                                                                                ">
                        </a>
                    </div>
                                    </div>
                                <div class="f-r-main" ectype="floor_cat_1115">
                    <ul class="p-list"></ul>
                </div>
                                <div class="f-r-main" ectype="floor_cat_1129">
                    <ul class="p-list"></ul>
                </div>
                                <div class="f-r-main" ectype="floor_cat_1145">
                    <ul class="p-list"></ul>
                </div>
                                <div class="f-r-main" ectype="floor_cat_1160">
                    <ul class="p-list"></ul>
                </div>
                            </div>
        </div>
    </div>
        <div class="floor-fd">
        <div class="floor-fd-brand clearfix">
                        <div class="item">
                <a href="brandn.php?id=72" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490072313895957648.jpg" title="ELLE HOME"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=73" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490072329183966195.jpg" title="她他/tata"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=109" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490074056964147533.jpg" title="诺基亚"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=110" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490074043963552715.jpg" title="松下电器"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=115" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490074006660107941.jpg" title="西门子"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=125" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490073960166035363.jpg" title="华为"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=130" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490074180745676140.jpg" title="TP-LINL"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=139" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490073705755280994.jpg" title="飞科"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=148" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490073603108687350.jpg" title="宏基"></div>
                    <div class="link"></div>
                </a>
            </div>
                        <div class="item">
                <a href="brandn.php?id=150" target="_blank">
                    <div class="link-l"></div>
                    <div class="img"><img src="http://demo.zz.jabrielcloud.com/data/brandlogo/1490073577683159021.jpg" title="华帝"></div>
                    <div class="link"></div>
                </a>
            </div>
                    </div>
    </div>
    </div>
<div class="spec" data-spec="" data-title="undefined"></div></div>
                                    </div>
                                </div><div class="visual-item w1200" data-mode="h-master" data-purebox="homeAdv" data-li="1" ectype="visualItme" style="display: block;" data-diff="0">
                                    
                                    <div class="view">
                                        <div class="master-channel" id="h-master_0" data-type="range" data-lift="达人">
 
<div class="ftit"><h3>达人</h3></div>
<div class="master-con">
            <div class="m-c-item m-c-i-1" style="background:url(http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985006295599886.jpg) center center no-repeat;">
        <div class="m-c-main">
            <div class="title">
                <h3>纯棉质品</h3>
                <span>把好货带回家</span>
            </div>
            <a href="" class="m-c-btn" target="_blank">去见识</a>
        </div>
        <div class="img"><a href="" target="_blank"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985002918483191.png"></a></div>
    </div>
                <div class="m-c-item m-c-i-2" style="background:url(http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985006392060862.jpg) center center no-repeat;">
        <div class="m-c-main">
            <div class="title">
                <h3>团购热卖</h3>
                <span>每一款都是好货</span>
            </div>
            <a href="" class="m-c-btn" target="_blank">去见识</a>
        </div>
        <div class="img"><a href="" target="_blank"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985002435254172.png"></a></div>
    </div>
                <div class="m-c-item m-c-i-3" style="background:url(http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985006452127966.jpg) center center no-repeat;">
        <div class="m-c-main">
            <div class="title">
                <h3>团购热卖</h3>
                <span>都是好货</span>
            </div>
            <a href="" class="m-c-btn" target="_blank">去见识</a>
        </div>
        <div class="img"><a href="" target="_blank"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985003577610926.png"></a></div>
    </div>
                <div class="m-c-item m-c-i-4" style="background:url(http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985006427221958.jpg) center center no-repeat;">
        <div class="m-c-main">
            <div class="title">
                <h3>舒适童鞋</h3>
                <span>帮宝宝学走路</span>
            </div>
            <a href="" class="m-c-btn" target="_blank">去见识</a>
        </div>
        <div class="img"><a href="" target="_blank"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985003958834850.png"></a></div>
    </div>
                <div class="m-c-item m-c-i-5" style="background:url(http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985005357290375.jpg) center center no-repeat;">
        <div class="m-c-main">
            <div class="title">
                <h3>双十二运动鞋</h3>
                <span>品牌直降</span>
            </div>
            <a href="" class="m-c-btn" target="_blank">去见识</a>
        </div>
        <div class="img"><a href="" target="_blank"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985004056329811.png"></a></div>
    </div>
        </div>
<div class="spec" data-spec="" data-title="达人"></div></div>
                                    </div>
                                </div><div class="visual-item w1200" data-mode="h-storeRec" data-purebox="homeAdv" data-li="1" ectype="visualItme" style="display: block;" data-diff="0">
                                    
                                    <div class="view">
                                        <div class="store-channel" id="h-storeRec_0" data-type="range" data-lift="店铺">
 
<div class="ftit"><h3>店铺</h3></div>
<div class="rec-store-list">
            <div class="rec-store-item opacity_img">
        <a href="" target="_blank">
            <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985261279846913.png"></div>
            <div class="info">
                <div class="s-logo"><div class="img"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985267980096546.png"></div></div>
                <div class="s-title">
                    <div class="tit">美宝莲</div>
                    <div class="ui-tit">纽约高潮街装</div>
                </div>
            </div>
        </a>
    </div>
                <div class="rec-store-item opacity_img">
        <a href="" target="_blank">
            <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985257347489575.png"></div>
            <div class="info">
                <div class="s-logo"><div class="img"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985265619204005.png"></div></div>
                <div class="s-title">
                    <div class="tit">三只松鼠</div>
                    <div class="ui-tit">就是这个味</div>
                </div>
            </div>
        </a>
    </div>
                <div class="rec-store-item opacity_img">
        <a href="" target="_blank">
            <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985254811159847.png"></div>
            <div class="info">
                <div class="s-logo"><div class="img"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985265516324065.png"></div></div>
                <div class="s-title">
                    <div class="tit">绿联旗舰店</div>
                    <div class="ui-tit">给生活多点色彩</div>
                </div>
            </div>
        </a>
    </div>
                <div class="rec-store-item opacity_img">
        <a href="" target="_blank">
            <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985263326444094.png"></div>
            <div class="info">
                <div class="s-logo"><div class="img"><img src="http://demo.zz.jabrielcloud.com/data/gallery_album/2/original_img/1494985267537609679.jpg"></div></div>
                <div class="s-title">
                    <div class="tit">韩都衣舍</div>
                    <div class="ui-tit">满249减50</div>
                </div>
            </div>
        </a>
    </div>
        </div>
<div class="spec" data-spec="" data-title="店铺"></div></div>
                                    </div>
                                </div><div class="visual-item w1200" data-mode="guessYouLike" data-purebox="goods" ectype="visualItme" data-diff="0" style="display: block;" data-goodsid="620,621,622,624,625,627,633,634,635,636,637,638,639,640,642,644,645,646,647,648">
                                    
                                    <div class="view">
                                        <div class="lift-channel clearfix" id="guessYouLike" data-type="range" data-lift="商品">
                                            <div data-goodstitle="title"><div class="ftit"><h3>还没逛够</h3></div></div>
                                            <ul>
 
<li class="opacity_img">
    <a href="goods.php?id=627" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489099773629.jpg"></div>
        <div class="p-name" title="2017春装新款男士卫衣套头圆领韩版潮流时尚男生休闲外套">2017春装新款男士卫衣套头圆领韩版潮流时尚男生休闲外套</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>200.00                            </div>
            <div class="original-price">240.00</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=625" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489099437211.jpg"></div>
        <div class="p-name" title="秋季新款男士套头卫衣印花外套韩版简约百搭潮流男生上衣服">秋季新款男士套头卫衣印花外套韩版简约百搭潮流男生上衣服</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>120.00                            </div>
            <div class="original-price">144.00</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=648" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489105257655.jpg"></div>
        <div class="p-name" title="Midea/美的 MB-WFS5017TM电饭煲5L智能正品电饭锅家用3-4-6-7-8人 下单立减20 精研柴火饭 涡轮防溢">Midea/美的 MB-WFS5017TM电饭煲5L智能正品电饭锅家用3-4-6-7-8人 下单立减20 精研柴火饭 涡轮防溢</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>300.00                            </div>
            <div class="original-price">360.00</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=647" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489105175252.jpg"></div>
        <div class="p-name" title="志高嵌入式电陶炉家用双头双灶镶嵌式电磁炉双眼光波炉特价正品 不挑锅可烧烤 三环猛火 嵌入式双灶">志高嵌入式电陶炉家用双头双灶镶嵌式电磁炉双眼光波炉特价正品 不挑锅可烧烤 三环猛火 嵌入式双灶</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>488.00                            </div>
            <div class="original-price">585.60</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=646" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489105134405.jpg"></div>
        <div class="p-name" title="美的电磁炉Midea/美的 WK2102电磁炉特价家用触摸屏电池炉灶正品 已爆售百万多台 防滑触摸屏 一键爆炒">美的电磁炉Midea/美的 WK2102电磁炉特价家用触摸屏电池炉灶正品 已爆售百万多台 防滑触摸屏 一键爆炒</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>455.00                            </div>
            <div class="original-price">546.00</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=645" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489105083498.jpg"></div>
        <div class="p-name" title="杰威尔发胶定型喷雾男士干胶头发持久定型造型啫喱水发蜡蓬松清香 快速定型，蓬松清香，不起白屑，买2送1">杰威尔发胶定型喷雾男士干胶头发持久定型造型啫喱水发蜡蓬松清香 快速定型，蓬松清香，不起白屑，买2送1</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>110.00                            </div>
            <div class="original-price">132.00</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=644" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489105021484.jpg"></div>
        <div class="p-name" title="欧莱雅男士水能保湿化妆护肤品套装深层补水滋润洗面奶爽肤水乳液">欧莱雅男士水能保湿化妆护肤品套装深层补水滋润洗面奶爽肤水乳液</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>60.00                            </div>
            <div class="original-price">72.00</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=642" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489104935834.jpg"></div>
        <div class="p-name" title="一叶子面膜女补水保湿收缩毛孔控油玻尿酸面膜专柜正品 共28片">一叶子面膜女补水保湿收缩毛孔控油玻尿酸面膜专柜正品 共28片</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>80.00                            </div>
            <div class="original-price">96.00</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=640" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489104621775.jpg"></div>
        <div class="p-name" title="花美时三合一自动旋转双头眉笔眉粉染眉膏画眉持久防水防汗不脱色 防水防汗 持久不晕染 正品包邮">花美时三合一自动旋转双头眉笔眉粉染眉膏画眉持久防水防汗不脱色 防水防汗 持久不晕染 正品包邮</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>200.00                            </div>
            <div class="original-price">240.00</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=639" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489104534699.jpg"></div>
        <div class="p-name" title="美宝莲绝色持久唇膏 粉红警报 魅惑炫亮润泽 唇彩口红">美宝莲绝色持久唇膏 粉红警报 魅惑炫亮润泽 唇彩口红</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>300.00                            </div>
            <div class="original-price">360.00</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=638" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489104168209.jpg"></div>
        <div class="p-name" title="美宝莲绝色持久唇膏 粉红警报 魅惑炫亮润泽 唇彩口红">美宝莲绝色持久唇膏 粉红警报 魅惑炫亮润泽 唇彩口红</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>520.00                            </div>
            <div class="original-price">624.00</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=637" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489103674623.jpg"></div>
        <div class="p-name" title="一叶子补水面膜女保湿控油深层清洁收毛孔护肤面膜贴套装专柜正品 补水保湿 清洁控油">一叶子补水面膜女保湿控油深层清洁收毛孔护肤面膜贴套装专柜正品 补水保湿 清洁控油</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>330.00                            </div>
            <div class="original-price">396.00</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=636" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489103412794.jpg"></div>
        <div class="p-name" title="The Face Shop 水光无瑕气垫CC霜 裸妆隔离保湿补水持久遮瑕强 韩式裸妆 打造水嫩遮瑕 光润亮彩">The Face Shop 水光无瑕气垫CC霜 裸妆隔离保湿补水持久遮瑕强 韩式裸妆 打造水嫩遮瑕 光润亮彩</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>222.00                            </div>
            <div class="original-price">266.40</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=635" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489102950633.jpg"></div>
        <div class="p-name" title="韩都衣舍2017韩版女装新款黑白拼接插肩棒球服春季短外套HH5597妠 朴信惠同款 黑白拼接 插肩袖 棒球服">韩都衣舍2017韩版女装新款黑白拼接插肩棒球服春季短外套HH5597妠 朴信惠同款 黑白拼接 插肩袖 棒球服</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>450.00                            </div>
            <div class="original-price">540.00</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=634" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489102753231.jpg"></div>
        <div class="p-name" title="新款韩版chic学生宽松短款外套上衣字母长袖连帽套头卫衣女潮">新款韩版chic学生宽松短款外套上衣字母长袖连帽套头卫衣女潮</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>300.00                            </div>
            <div class="original-price">360.00</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=633" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489102299856.jpg"></div>
        <div class="p-name" title="新款学院风韩版时尚太空棉宽松长袖印花圆领卫衣女">新款学院风韩版时尚太空棉宽松长袖印花圆领卫衣女</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>233.00                            </div>
            <div class="original-price">279.59</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=624" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489099128797.jpg"></div>
        <div class="p-name" title="名龙堂i7 6700升7700 GTX1060 6G台式电脑主机DIY游戏组装整机 升6GB独显 送正版WIN10 一年上门">名龙堂i7 6700升7700 GTX1060 6G台式电脑主机DIY游戏组装整机 升6GB独显 送正版WIN10 一年上门</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>4300.00                            </div>
            <div class="original-price">5160.00</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=622" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489098597912.jpg"></div>
        <div class="p-name" title="Apple/苹果 27” Retina 5K显示屏 iMac:3.3GHz处理器2TB存储">Apple/苹果 27” Retina 5K显示屏 iMac:3.3GHz处理器2TB存储</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>8999.00                            </div>
            <div class="original-price">10798.80</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=621" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489098360804.jpg"></div>
        <div class="p-name" title="三星C24F396FH曲面显示器23.5英寸电脑显示器24液晶显示屏幕超22">三星C24F396FH曲面显示器23.5英寸电脑显示器24液晶显示屏幕超22</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>2200.00                            </div>
            <div class="original-price">2640.00</div>
        </div>
    </a>
</li>
<li class="opacity_img">
    <a href="goods.php?id=620" target="_blank">
        <div class="p-img"><img src="http://demo.zz.jabrielcloud.com/images/201703/thumb_img/0_thumb_G_1489098265067.jpg"></div>
        <div class="p-name" title="新品HYC 2k显示器32寸电脑显示器无边框HDMI液晶显示器IPS显示屏 2K高清屏IPS 超薄 厚6mm 无边框">新品HYC 2k显示器32寸电脑显示器无边框HDMI液晶显示器IPS显示屏 2K高清屏IPS 超薄 厚6mm 无边框</div>
        <div class="p-price">
            <div class="shop-price">
                                <em>¥</em>1500.00                            </div>
            <div class="original-price">1800.00</div>
        </div>
    </a>
</li>
</ul>
                                        <div class="spec" data-spec=""></div></div>
                                    </div>
                                </div></div>                                                                                                                                                                                                                                                                                                                                                                                    
        <div class="attached-search-container" ectype="suspColumn">
            <div class="w w1200">
                <div class="categorys site-mast">
                    <div class="categorys-type"><a href="categoryall.php" target="_blank">全部商品分类</a></div>
                    <div class="categorys-tab-content">
                        554fcae493e564ee0dc75bdf2ebf94cacategory_tree_nav|a:3:{s:4:"name";s:17:"category_tree_nav";s:9:"cat_model";s:1:"0";s:7:"cat_num";i:7;}554fcae493e564ee0dc75bdf2ebf94ca                    </div>
                </div>
                <div class="mall-search">
                   <div class="dsc-search">
                        <div class="form">
                            <form id="searchForm" name="searchForm" method="get" action="search.php" onSubmit="return checkSearchForm(this)" class="search-form">
                                <input autocomplete="off" name="keywords" type="text" id="keyword2" value="554fcae493e564ee0dc75bdf2ebf94carand_keyword|a:1:{s:4:"name";s:12:"rand_keyword";}554fcae493e564ee0dc75bdf2ebf94ca" class="search-text"/>
                                <input type="hidden" name="store_search_cmt" value="0">
                                <button type="submit" class="button button-goods" onclick="checkstore_search_cmt(0)">搜商品</button>
                                <button type="submit" class="button button-store" onclick="checkstore_search_cmt(1)">搜店铺</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="suspend-login">
                    554fcae493e564ee0dc75bdf2ebf94caindex_suspend_info|a:1:{s:4:"name";s:18:"index_suspend_info";}554fcae493e564ee0dc75bdf2ebf94ca                </div>
                <div class="shopCart" id="ECS_CARTINFO">
                    554fcae493e564ee0dc75bdf2ebf94cacart_info|a:1:{s:4:"name";s:9:"cart_info";}554fcae493e564ee0dc75bdf2ebf94ca                </div>
            </div>
    	</div>
        <div class="lift lift-mode-one lift-hide" ectype="lift" data-type="one" style="z-index:100001">
            <div class="lift-list" ectype="liftList">
            </div>
        </div>
        
        <input name="warehouse_id" type="hidden" value="2">
    	<input name="area_id" type="hidden" value="27">
        <input name="area_city" type="hidden" value="558">
        <input name="temp" type="hidden" value="backup_tpl_1">
        
        
    	<div ectype="bonusadv_box"></div>
    </div>
    
    554fcae493e564ee0dc75bdf2ebf94causer_menu_position|a:1:{s:4:"name";s:18:"user_menu_position";}554fcae493e564ee0dc75bdf2ebf94ca    <div class="footer-new">
    <div class="footer-new-top">
    	<div class="w w1200">
            <div class="service-list">
                <div class="service-item">
                    <i class="f-icon f-icon-qi"></i>
                    <span>七天包退</span>
                </div>
                <div class="service-item">
                    <i class="f-icon f-icon-zheng"></i>
                    <span>正品保障</span>
                </div>
                <div class="service-item">
                    <i class="f-icon f-icon-hao"></i>
                    <span>好评如潮</span>
                </div>
                <div class="service-item">
                    <i class="f-icon f-icon-shan"></i>
                    <span>闪电发货</span>
                </div>
                <div class="service-item">
                    <i class="f-icon f-icon-quan"></i>
                    <span>权威荣誉</span>
                </div>
            </div>
            <div class="contact">
                <div class="contact-item contact-item-first"><i class="f-icon f-icon-tel"></i><span>027-87158232</span></div>
                <div class="contact-item">
                	                    <a id="IM" IM_type="dsc" onclick="openWin(this)" href="javascript:;" class="btn-ctn"><i class="f-icon f-icon-kefu"></i><span>咨询客服</span></a>
                                    </div>
            </div>
        </div>
    </div>
    <div class="footer-new-con">
    	<div class="fnc-warp">
            <div class="help-list">
                                                <div class="help-item">
                    <h3>配送与支付 </h3>
                    <ul>
                                                            <li><a href="article.php?id=55"  title="上门自提" target="_blank">上门自提</a></li>
                                                                                <li><a href="article.php?id=17"  title="支付方式说明" target="_blank">支付方式说明</a></li>
                                                                                <li><a href="article.php?id=16"  title="配送支付智能查询 " target="_blank">配送支付智能查询</a></li>
                                                                                                    </ul>
                </dl>
                </div>
                                                                <div class="help-item">
                    <h3>新手上路 </h3>
                    <ul>
                                                            <li><a href="article.php?id=36"  title="隐私声明" target="_blank">隐私声明</a></li>
                                                                                <li><a href="article.php?id=11"  title="订购方式" target="_blank">订购方式</a></li>
                                                                                <li><a href="article.php?id=10"  title="购物流程" target="_blank">购物流程</a></li>
                                                                                                    </ul>
                </dl>
                </div>
                                                                <div class="help-item">
                    <h3>联系我们 </h3>
                    <ul>
                                                            <li><a href="article.php?id=26"  title="投诉与建议 " target="_blank">投诉与建议</a></li>
                                                                                <li><a href="article.php?id=25"  title="选机咨询 " target="_blank">选机咨询</a></li>
                                                                                <li><a href="article.php?id=24"  title="网站故障报告" target="_blank">网站故障报告</a></li>
                                                            </ul>
                </dl>
                </div>
                                                                <div class="help-item">
                    <h3>服务保证 </h3>
                    <ul>
                                                            <li><a href="article.php?id=23"  title="产品质量保证 " target="_blank">产品质量保证</a></li>
                                                                                <li><a href="article.php?id=22"  title="售后服务保证" target="_blank">售后服务保证</a></li>
                                                                                <li><a href="article.php?id=21"  title="退换货原则" target="_blank">退换货原则</a></li>
                                                            </ul>
                </dl>
                </div>
                                                                <div class="help-item">
                    <h3>会员中心</h3>
                    <ul>
                                                            <li><a href="article.php?id=20"  title="我的订单" target="_blank">我的订单</a></li>
                                                                                <li><a href="article.php?id=19"  title="我的收藏" target="_blank">我的收藏</a></li>
                                                                                <li><a href="article.php?id=18"  title="资金管理" target="_blank">资金管理</a></li>
                                                            </ul>
                </dl>
                </div>
                                  
            </div>
            <div class="qr-code">
                <div class="qr-item qr-item-first">
                    <div class="code_img"><img src="images/common/ecjia_qrcode.png"></div>
                    <div class="code_txt">微信公众号</div>
                </div>
                <div class="qr-item">
                    <div class="code_img"><img src="images/common/ectouch_qrcode.png"></div>
                    <div class="code_txt">商城移动端</div>
                </div>
            </div>
    	</div>
    </div>
    <div class="footer-new-bot">
    	<div class="w w1200">
             
            <p class="copyright_links">
                                <a href="index.php">首页</a>
                 
                <span class="spacer"></span>
                 
                                <a href="article.php?id=2">隐私保护</a>
                 
                <span class="spacer"></span>
                 
                                <a href="article.php?id=4">联系我们</a>
                 
                <span class="spacer"></span>
                 
                                <a href="article.php?id=1">免责条款</a>
                 
                <span class="spacer"></span>
                 
                                <a href="article.php?id=5">公司简介</a>
                 
                <span class="spacer"></span>
                 
                                <a href="merchants.php" target="_blank" >商家入驻</a>
                 
                <span class="spacer"></span>
                 
                                <a href="message.php">意见反馈</a>
                 
                 
            </p>
                        
                        <p class="copyright_links">
                                    
                                                    <a href="http://www.jabrielcloud.com" target="_blank" title="加布里埃尔">加布里埃尔</a>
                                                                </p>
                        
                        <p><span>©&nbsp;2015-2018&nbsp; jabrielcloud.com&nbsp;版权所有&nbsp;&nbsp;</span><span>ICP备案证书号:</span><a href="http://www.miit.gov.cn/" target="_blank">鄂ICP备19029458号-1</a>&nbsp;POWERED by<a href="http://www.jabrielcloud.com/" target="_blank">文旅新零售平台</a>2.0</p>
                        
                        <p class="copyright_auth">&nbsp;</p>
                        
                    </div>
    </div>
    
    
    <div class="hide" id="pd_coupons">
        <span class="success-icon m-icon"></span>
        <div class="item-fore">
            <h3>领取成功！感谢您的参与，祝您购物愉快~</h3>
            <div class="txt ftx-03">本活动为概率性事件，不能保证所有客户成功领取优惠券</div>
        </div>
    </div>
    
    
    <div class="hidden">
        <input type="hidden" name="seller_kf_IM" value="" rev="" ru_id="0" />
        <input type="hidden" name="seller_kf_qq" value="82542370" />
        <input type="hidden" name="seller_kf_tel" value="027-87158232" />
        <input type="hidden" name="user_id" ectype="user_id" value="0" />
    </div>
</div>
<script type="text/javascript" src="js/suggest.js"></script><script type="text/javascript" src="js/scroll_city.js"></script><script type="text/javascript" src="js/utils.js"></script>
<script type="text/javascript" src="js/warehouse.js"></script><script type="text/javascript" src="js/warehouse_area.js"></script>
    <script type="text/javascript" src="js/jquery.SuperSlide.2.1.1.js"></script><script type="text/javascript" src="js/jquery.yomi.js"></script><script type="text/javascript" src="js/cart_common.js"></script><script type="text/javascript" src="js/cart_quick_links.js"></script>    <script type="text/javascript" src="themes/ecmoban_dsc2017/js/dsc-common.js"></script>
    <script type="text/javascript" src="themes/ecmoban_dsc2017/js/asyLoadfloor.js"></script>
    <script type="text/javascript" src="themes/ecmoban_dsc2017/js/jquery.purebox.js"></script>
    <script type="text/javascript">
		/*首页轮播*/
		var slideType = $("*[data-mode='lunbo']").find("*[data-type='range']").data("slide");
		var length = $(".banner .bd").find("li").length;
		
		if(slideType == "roll"){
			slideType = "left";
		}
		
		if(length>1){
			$(".banner").slide({titCell:".hd ul",mainCell:".bd ul",effect:slideType,interTime:5000,delayTime:500,autoPlay:true,autoPage:true,trigger:"click",endFun:function(i,c,s){
				$(window).resize(function(){
					var width = $(window).width();
					if(!$('body').hasClass("festival_home")){
						s.find(".bd li").css("width",width);
					}
				});
			}});
		}else{
			$(".banner .hd").hide();
		}
		
		//楼层二级分类商品切换
		$("*[ectype='floorItem']").slide({titCell:".hd-tags li",mainCell:".floor-tabs-content",titOnClassName:"current"});
		
		$("*[ectype='floorItem']").slide({titCell:".floor-nav li",mainCell:".floor-tabs-content",titOnClassName:"current"});
		
		//第五套楼层模板
		$(".floor-fd-slide").slide({mainCell:".bd ul",effect:"left",autoPlay:false,autoPage:true,vis:4,scroll:1,prevCell:".ff-prev",nextCell:".ff-next"});
		
		//第六套楼层模板
		$(".floor-brand").slide({mainCell:".fb-bd ul",effect:"left",pnLoop:true,autoPlay:false,autoPage:true,vis:3,scroll:1,prevCell:".fs_prev",nextCell:".fs_next"});
		
		//楼层轮播图广告
		$("*[data-purebox='homeFloor']").each(function(index, element) {
			var f_slide_length = $(this).find(".floor-left-slide .bd li").length;
			if(f_slide_length > 1){
				$(element).find(".floor-left-slide").slide({titCell:".hd ul",mainCell:".bd ul",effect:"left",interTime:3500,delayTime:500,autoPlay:true,autoPage:true});
			}else{
				$(element).find(".floor-left-slide .hd").hide();
			}
        });
		//异步加载出首页个人信息、秒杀活动、品牌信息、首页弹出广告
        $(function(){
            var site_domain = "";
            var brand_id = $('*[ectype="homeBrand"]').find(".brand-list").data("value");
			var seckillid = $('[data-mode="h-seckill"]').find('[data-type="range"]').data('seckillid');
			var temp = "backup_tpl_1";
			
			var where = '';
			if(!brand_id){
				brand_id = '';
			}
			
            seckillid = JSON.stringify(seckillid);
			
            if(site_domain){
				$.ajax({
					type: "GET",
					url: "ajax_dialog.php", /*jquery Ajax跨域*/
					data: "act=getUserInfo&is_jsonp=1&brand_id="+brand_id + "&seckillid=" + seckillid + "&temp=" + temp,
					dataType:"jsonp",
					jsonp:"jsoncallback",
					success: homeAjax
				});
            }else{
                Ajax.call('ajax_dialog.php?act=getUserInfo', 'brand_id=' + brand_id + "&seckillid=" + seckillid + "&temp=" + temp, homeAjax , 'POST', 'JSON');
            }
			
			function ajax_Homeindex_Bonusadv(){
				var cfg_bonus_adv = "1";//是否开启首页弹出广告
				var suffix = "backup_tpl_1";
				
				if(cfg_bonus_adv == 1 && suffix){
					Ajax.call('ajax_dialog.php?act=ajax_Homeindex_Bonusadv', 'suffix=' + suffix, function(data){
						if(data.error != 1){
							$("[ectype='bonusadv_box']").html(data.content);
						}
					} , 'POST', 'JSON');
				}
			}
			
			ajax_Homeindex_Bonusadv();
			
			function homeAjax(data){
				$("*[ectype='user_info']").html(data.content);
				$("*[ectype='homeBrand']").html(data.brand_list);
				if(data.seckill_goods){
					$('[data-mode="h-seckill"]').show().find('[data-type="range"] .box-bd').html(data.seckill_goods);
					var sec_begin_time =  $('[data-mode="h-seckill"]').find('[data-type="range"] .box-bd').find('input[name="sec_begin_time"]').val();
					var sec_end_time = $('[data-mode="h-seckill"]').find('[data-type="range"] .box-bd').find('input[name="sec_end_time"]').val();
					if(sec_begin_time){
						$('[data-mode="h-seckill"]').find('[data-type="range"] .box-hd [ectype="time"]').attr("data-time",sec_begin_time)
					}else{
						$('[data-mode="h-seckill"]').find('[data-type="range"] .box-hd [ectype="time"]').attr("data-time",sec_end_time)
					}
					$("*[ectype='time']").each(function(){
						$(this).yomi();
					});
					//首页秒杀商品滚动
					$(".seckill-channel").slide({mainCell:".box-bd ul",effect:"leftLoop",autoPlay:true,autoPage:true,interTime:5000,delayTime:500,vis:5,scroll:1,trigger:"click"});
				}else{
					$('[data-mode="h-seckill"]').hide();
				}
				
				$.catetopLift();
				
				$(window).scroll(function(){
					var scrollTop = $(document).scrollTop();
					var navTop = $("*[ectype='dscNav']").offset().top;  //by yanxin
						
					if(scrollTop>navTop){
						$("*[ectype='suspColumn']").addClass("show");
					}else{
						$("*[ectype='suspColumn']").removeClass("show");
					}
				});
			}
                        
			//重新加载商品模块
			$("[data-mode='guessYouLike']").each(function(){
				var _this = $(this);
				var goods_ids = _this.data("goodsid");
				var warehouse_id = $("input[name='warehouse_id']").val();
				var area_id = $("input[name='area_id']").val();
				var area_city = $("input[name='area_city']").val();
				if(goods_ids){
					Ajax.call('ajax_dialog.php?act=getguessYouLike', 'goods_ids=' + goods_ids + "&warehouse_id=" + warehouse_id + "&area_id=" + area_id + "&area_city=" + area_city, function(data){
						if(data.content){
							_this.find(".view .lift-channel ul").html(data.content);
						}
					} , 'POST', 'JSON');
				}
			});
                       
			$("li[ectype='floor_cat_content'].current").each(function(){
				 get_homefloor_cat_content(this);
			});
			
			$("[ectype='identi_floorgoods'].current").each(function(){
				 get_homefloor_cat_content(this);
			});
			
			function checked_article_cat(){
				var cat_ids = '';
				
				$('[data-mode="insertVipEdit"] .tit a').each(function(){
					var val = $(this).data('catid');
					if(cat_ids){
						cat_ids = cat_ids + "," + val;
					}else{
						cat_ids = val;
					}
				});
				
				if(cat_ids){
					Ajax.call('ajax_dialog.php?act=checked_article_cat', 'cat_ids=' + cat_ids, function(data){
						$('[data-mode="insertVipEdit"] .vip_article_cat').html(data.content);
						
						//首页信息栏 新闻文章切换 
						$(".vip-item").slide({titCell:".tit a",mainCell:".con"});
					} , 'POST', 'JSON');
				}
			}
			checked_article_cat();
                        //异步新品排行
                        $("[ectype='h-phb3']").each(function(){
				 var _this = $(this);
                                 var activitytype = _this.data('activitytype');
                                 var goodsids = _this.data('goodsids');
                                 var warehouse_id = $("input[name='warehouse_id']").val();
				var area_id = $("input[name='area_id']").val();
                                
                                 Ajax.call('ajax_dialog.php?act=checked_home_rank', 'goodsids=' + goodsids + "&activitytype=" + activitytype + "&warehouse_id=" + warehouse_id + "&area_id=" + area_id, function(data){
						_this.html(data.content);
					} , 'POST', 'JSON');
			});
        });
		
		//楼层左侧栏悬浮框
		readyLoad();
		
		//会员名称*号 by yanxin
		/*var name = $(".suspend-login a.nick_name").text();
		var star = new Array();
		var nameLen = name.length > 2 ? name.length-2:"1";
		for(var i=1;i<=nameLen;i++){
			star.push("*");
		}
		star = star.join("");
		if(name.length > 2){
			var new_name = name[0] + star + name[name.length-1];
		}else{
			var new_name = name[0] + star;
		}
		$(".suspend-login a.nick_name").text(new_name);
		*/
		//去掉悬浮框 我的购物车
		$(".attached-search-container .shopCart-con a span").text("");
		
		/*首页可视化 第八套模板 楼层左侧前后轮播 */
		aroundSilder(".floor_silder")
    </script>
</body>
</html>
