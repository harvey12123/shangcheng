<?php exit;?>a:3:{s:8:"template";a:6:{i:0;s:57:"/www/site/demo/zz/themes/ecmoban_dsc2017/store_street.dwt";i:1;s:69:"/www/site/demo/zz/themes/ecmoban_dsc2017/library/js_languages_new.lbi";i:2;s:71:"/www/site/demo/zz/themes/ecmoban_dsc2017/library/page_header_common.lbi";i:3;s:69:"/www/site/demo/zz/themes/ecmoban_dsc2017//library/store_shop_list.lbi";i:4;s:64:"/www/site/demo/zz/themes/ecmoban_dsc2017//library/pages_ajax.lbi";i:5;s:64:"/www/site/demo/zz/themes/ecmoban_dsc2017/library/page_footer.lbi";}s:7:"expires";i:1585403153;s:8:"maketime";i:1585399553;}<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Keywords" content="文旅新零售平台 加布里埃尔 商城系统 B2B2C 多商户系统  多店铺商城系统 企业级电商系统" />
<meta name="Description" content="文旅新零售平台是由武汉加布里埃尔推出的B2B2C商城系统，支持多店铺入驻、多城市、多仓库、在线批发进货、三级分销等功能" />
<title>店铺街_文旅新零售平台-B2B2C商城平台</title>
<link rel="shortcut icon" href="favicon.ico" />
<link rel="stylesheet" type="text/css" href="themes/ecmoban_dsc2017/css/base.css" />
<link rel="stylesheet" type="text/css" href="themes/ecmoban_dsc2017/css/style.css" />
<link rel="stylesheet" type="text/css" href="themes/ecmoban_dsc2017/css/iconfont.css" />
<link rel="stylesheet" type="text/css" href="themes/ecmoban_dsc2017/css/purebox.css" />
<link rel="stylesheet" type="text/css" href="themes/ecmoban_dsc2017/css/quickLinks.css" />
<script type="text/javascript" src="js/jquery-1.9.1.min.js"></script><script type="text/javascript" src="js/jquery.json.js"></script><script type="text/javascript" src="js/transport_jquery.js"></script>
<script type="text/javascript">
var json_languages = {"ok":"\u786e\u5b9a","determine":"\u786e\u5b9a","cancel":"\u53d6\u6d88","drop":"\u5220\u9664","edit":"\u7f16\u8f91","remove":"\u79fb\u9664","follow":"\u5173\u6ce8","pb_title":"\u63d0\u793a","Prompt_information":"\u63d0\u793a\u4fe1\u606f","title":"\u63d0\u793a","not_login":"\u60a8\u5c1a\u672a\u767b\u5f55","close":"\u5173\u95ed","cart":"\u8d2d\u7269\u8f66","js_cart":"\u8d2d\u7269\u8f66","all":"\u5168\u90e8","go_login":"\u53bb\u767b\u9646","select_city":"\u8bf7\u9009\u62e9\u5e02","comment_goods":"\u8bc4\u8bba\u5546\u54c1","submit_order":"\u63d0\u4ea4\u8ba2\u5355","sys_msg":"\u7cfb\u7edf\u63d0\u793a","no_keywords":"\u8bf7\u8f93\u5165\u641c\u7d22\u5173\u952e\u8bcd\uff01","adv_packup_one":"\u8bf7\u53bb\u540e\u53f0\u5e7f\u544a\u4f4d\u7f6e","adv_packup_two":"\u91cc\u9762\u8bbe\u7f6e\u5e7f\u544a\uff01","more":"\u66f4\u591a","Please":"\u8bf7\u53bb","set_up":"\u8bbe\u7f6e\uff01","login_phone_packup_one":"\u8bf7\u8f93\u5165\u624b\u673a\u53f7\u7801","more_options":"\u66f4\u591a\u9009\u9879","Pack_up":"\u6536\u8d77","no_attr":"\u6ca1\u6709\u66f4\u591a\u5c5e\u6027\u4e86","search_Prompt":"\u53ef\u8f93\u5165\u6c49\u5b57,\u62fc\u97f3\u67e5\u627e\u54c1\u724c","most_input":"\u6700\u591a\u53ea\u80fd\u9009\u62e95\u9879","multi_select":"\u591a\u9009","checkbox_Packup":"\u8bf7\u6536\u8d77\u5168\u90e8\u591a\u9009","radio_Packup":"\u8bf7\u6536\u8d77\u5168\u90e8\u5355\u9009","contrast":"\u5bf9\u6bd4","empty_contrast":"\u6e05\u7a7a\u5bf9\u6bd4\u680f","Prompt_add_one":"\u6700\u591a\u53ea\u80fd\u6dfb\u52a04\u4e2a\u54e6^_^","Prompt_add_two":"\u60a8\u8fd8\u53ef\u4ee5\u7ee7\u7eed\u6dfb\u52a0","button_compare":"\u6bd4\u8f83\u9009\u5b9a\u5546\u54c1","exist":"\u60a8\u5df2\u7ecf\u9009\u62e9\u4e86%s","count_limit":"\u6700\u591a\u53ea\u80fd\u9009\u62e94\u4e2a\u5546\u54c1\u8fdb\u884c\u5bf9\u6bd4","goods_type_different":"%s\u548c\u5df2\u9009\u62e9\u5546\u54c1\u7c7b\u578b\u4e0d\u540c\u65e0\u6cd5\u8fdb\u884c\u5bf9\u6bd4","compare_no_goods":"\u60a8\u6ca1\u6709\u9009\u5b9a\u4efb\u4f55\u9700\u8981\u6bd4\u8f83\u7684\u5546\u54c1\u6216\u8005\u6bd4\u8f83\u7684\u5546\u54c1\u6570\u5c11\u4e8e 2 \u4e2a\u3002","btn_buy":"\u8d2d\u4e70","is_cancel":"\u53d6\u6d88","select_spe":"\u8bf7\u9009\u62e9\u5546\u54c1\u5c5e\u6027","Country":"\u8bf7\u9009\u62e9\u6240\u5728\u56fd\u5bb6","Province":"\u8bf7\u9009\u62e9\u6240\u5728\u7701\u4efd","City":"\u8bf7\u9009\u62e9\u6240\u5728\u5e02","District":"\u8bf7\u9009\u62e9\u6240\u5728\u533a\u57df","Street":"\u8bf7\u9009\u62e9\u6240\u5728\u8857\u9053","Detailed_address_null":"\u8be6\u7ec6\u5730\u5740\u4e0d\u80fd\u4e3a\u7a7a","consignee":"\u8bf7\u586b\u5199\u6536\u8d27\u4eba\u4fe1\u606f","Select_attr":"\u8bf7\u9009\u62e9\u5c5e\u6027","Focus_prompt_one":"\u60a8\u5df2\u5173\u6ce8\u8be5\u5e97\u94fa\uff01","Focus_prompt_login":"\u60a8\u5c1a\u672a\u767b\u5f55\u5546\u57ce\u4f1a\u5458\uff0c\u4e0d\u80fd\u5173\u6ce8\uff01","Focus_prompt_two":"\u767b\u5f55\u5546\u57ce\u4f1a\u5458\u3002","store_focus":"\u5e97\u94fa\u5173\u6ce8\u3002","Focus_prompt_three":"\u60a8\u786e\u5b9e\u8981\u5173\u6ce8\u6240\u9009\u5e97\u94fa\u5417\uff1f","Focus_prompt_four":"\u60a8\u786e\u5b9e\u8981\u53d6\u6d88\u5173\u6ce8\u5e97\u94fa\u5417\uff1f","Focus_prompt_five":"\u60a8\u8981\u5173\u6ce8\u8be5\u5e97\u94fa\u5417\uff1f","Purchase_quantity":"\u8d85\u8fc7\u9650\u8d2d\u6570\u91cf.","My_collection":"\u6211\u7684\u6536\u85cf","shiping_prompt":"\u6682\u4e0d\u652f\u6301\u914d\u9001","Have_goods":"\u6709\u8d27","No_goods":"\u65e0\u8d27","No_shipping":"\u65e0\u6cd5\u914d\u9001","Deliver_back_order":"\u4e0b\u5355\u540e\u7acb\u5373\u53d1\u8d27","Time_delivery":" \u65f6\u53d1\u8d27","goods_over":"\u6b64\u5546\u54c1\u6682\u65f6\u552e\u5b8c","Stock_goods_null":"\u5546\u54c1\u5e93\u5b58\u4e0d\u8db3","purchasing_prompt_two":"\u5bf9\u4e0d\u8d77\uff0c\u8be5\u5546\u54c1\u5df2\u7ecf\u7d2f\u8ba1\u8d85\u8fc7\u9650\u8d2d\u6570\u91cf","day_not_available":"\u5f53\u65e5\u65e0\u8d27","day_yes_available":"\u5f53\u65e5\u6709\u8d27","Already_buy":"\u5df2\u8d2d\u4e70","Already_buy_two":"\u4ef6\u5546\u54c1\u8fbe\u5230\u9650\u8d2d\u6761\u4ef6,\u65e0\u6cd5\u518d\u8d2d\u4e70","Already_buy_three":"\u4ef6\u8be5\u5546\u54c1,\u53ea\u80fd\u518d\u8d2d\u4e70","goods_buy_empty_p":"\u5546\u54c1\u6570\u91cf\u4e0d\u80fd\u5c11\u4e8e1\u4ef6","goods_number_p":"\u5546\u54c1\u6570\u91cf\u5fc5\u987b\u4e3a\u6570\u5b57","search_one":"\u8bf7\u586b\u5199\u7b5b\u9009\u4ef7\u683c","search_two":"\u8bf7\u586b\u5199\u7b5b\u9009\u5de6\u8fb9\u4ef7\u683c","search_three":"\u8bf7\u586b\u5199\u7b5b\u9009\u53f3\u8fb9\u4ef7\u683c","search_four":"\u5de6\u8fb9\u4ef7\u683c\u4e0d\u80fd\u5927\u4e8e\u6216\u7b49\u4e8e\u53f3\u8fb9\u4ef7\u683c","jian":"\u4ef6","letter":"\u4ef6","inventory":"\u5b58\u8d27","move_collection":"\u79fb\u81f3\u6211\u7684\u6536\u85cf","select_shop":"\u8bf7\u9009\u62e9\u5957\u9910\u5546\u54c1","Parameter_error":"\u53c2\u6570\u9519\u8bef","screen_price":"\u8bf7\u586b\u5199\u7b5b\u9009\u4ef7\u683c","screen_price_left":"\u8bf7\u586b\u5199\u7b5b\u9009\u5de6\u8fb9\u4ef7\u683c","screen_price_right":"\u8bf7\u586b\u5199\u7b5b\u9009\u53f3\u8fb9\u4ef7\u683c","screen_price_dy":"\u5de6\u8fb9\u4ef7\u683c\u4e0d\u80fd\u5927\u4e8e\u6216\u7b49\u4e8e\u53f3\u8fb9\u4ef7\u683c","invoice_ok":"\u4fdd\u5b58\u53d1\u7968\u4fe1\u606f","invoice_desc_null":"\u8f93\u5165\u5185\u5bb9\u4e0d\u80fd\u4e3a\u7a7a\uff01","invoice_desc_number":"\u60a8\u6700\u591a\u53ef\u4ee5\u6dfb\u52a03\u4e2a\u516c\u53f8\u53d1\u7968\uff01","invoice_packup":"\u8bf7\u9009\u62e9\u6216\u586b\u5199\u53d1\u7968\u62ac\u5934\u90e8\u5206\uff01","invoice_tax_null":"\u8bf7\u586b\u5199\u7eb3\u7a0e\u4eba\u8bc6\u522b\u7801","add_address_10":"\u6700\u591a\u53ea\u80fd\u6dfb\u52a010\u4e2a\u6536\u8d27\u5730\u5740","msg_phone_not":"\u624b\u673a\u53f7\u7801\u4e0d\u6b63\u786e","msg_phone_blank":"\u624b\u673a\u53f7\u7801\u4e0d\u80fd\u4e3a\u7a7a","captcha_not":"\u9a8c\u8bc1\u7801\u4e0d\u80fd\u4e3a\u7a7a","captcha_xz":"\u8bf7\u8f93\u51654\u4f4d\u6570\u7684\u9a8c\u8bc1\u7801","captcha_cw":"\u9a8c\u8bc1\u7801\u9519\u8bef","Detailed_map":"\u8be6\u7ec6\u5730\u56fe","email_error":"\u90ae\u7bb1\u683c\u5f0f\u4e0d\u6b63\u786e\uff01","bid_prompt_null":"\u4ef7\u683c\u4e0d\u80fd\u4e3a\u7a7a!","bid_prompt_error":"\u4ef7\u683c\u8f93\u5165\u683c\u5f0f\u4e0d\u6b63\u786e\uff01","mobile_error_goods":"\u624b\u673a\u683c\u5f0f\u4e0d\u6b63\u786e\uff01","null_email_goods":"\u90ae\u7bb1\u4e0d\u80fd\u4e3a\u7a7a","select_store":"\u8bf7\u9009\u62e9\u95e8\u5e97\uff01","Product_spec_prompt":"\u8bf7\u9009\u62e9\u5546\u54c1\u89c4\u683c\u7c7b\u578b","reply_desc_one":"\u56de\u590d\u5e16\u5b50\u5185\u5bb9\u4e0d\u80fd\u4e3a\u7a7a","go_shoping":"\u53bb\u8d2d\u7269","loading":"\u6b63\u5728\u62fc\u547d\u52a0\u8f7d\u4e2d...","purchasing_minamount":"\u5bf9\u4e0d\u8d77\uff0c\u8d2d\u4e70\u6570\u91cf\u4e0d\u80fd\u5c0f\u4e8e\u6700\u5c0f\u9636\u68af\u4ef7","no_history":"\u60a8\u5df2\u6e05\u7a7a\u6700\u8fd1\u6d4f\u89c8\u8fc7\u7684\u5546\u54c1","emailInfo_incompleted":"\u60a8\u7684\u90ae\u7bb1\u4fe1\u606f\u672a\u8ba4\u8bc1\uff0c\u8fdb\u5165\u7528\u6237\u4e2d\u5fc3<a href='user.php?act=profile' class='red' target='_blank'>\u5b8c\u5584\u90ae\u7bb1\u4fe1\u606f<\/a>","receive_coupons":"\u9886\u53d6\u4f18\u60e0\u5238","Immediate_use":"\u7acb\u5373\u4f7f\u7528","no_enabled":"\u5173\u95ed","highest_price":"\u5df2\u662f\u6700\u9ad8\u4ef7\uff01","lowest_price":"\u5df2\u662f\u6700\u4f4e\u4ef7\uff01"};
//加载效果
var load_cart_info = '<img src="themes/ecmoban_dsc2017/images/load/loadGoods.gif" class="load" />';
var load_icon = '<img src="themes/ecmoban_dsc2017/images/load/load.gif" width="200" height="200" />';
</script><link rel="stylesheet" type="text/css" href="themes/ecmoban_dsc2017/css/suggest.css" />
</head>
<body>
	554fcae493e564ee0dc75bdf2ebf94caget_adv|a:2:{s:4:"name";s:7:"get_adv";s:9:"logo_name";N;}554fcae493e564ee0dc75bdf2ebf94ca<div class="site-nav" id="site-nav">
    <div class="w w1200">
        <div class="fl">
			554fcae493e564ee0dc75bdf2ebf94caheader_region|a:1:{s:4:"name";s:13:"header_region";}554fcae493e564ee0dc75bdf2ebf94ca            <div class="txt-info" id="ECS_MEMBERZONE">
				554fcae493e564ee0dc75bdf2ebf94camember_info|a:1:{s:4:"name";s:11:"member_info";}554fcae493e564ee0dc75bdf2ebf94ca	
            </div>
        </div>
        <ul class="quick-menu fr">
                                                <li>
                <div class="dt"><a href="user.php?act=order_list" >我的订单</a></div>
            </li>
            <li class="spacer"></li>
                                                <li>
                <div class="dt"><a href="history_list.php" >我的浏览</a></div>
            </li>
            <li class="spacer"></li>
                                                <li>
                <div class="dt"><a href="user.php?act=collection_list" >我的收藏</a></div>
            </li>
            <li class="spacer"></li>
                                                <li>
                <div class="dt"><a href="user.php?act=message_list" >客户服务</a></div>
            </li>
            <li class="spacer"></li>
                                                                                                                                                                                                                                    <li class="li_dorpdown" data-ectype="dorpdown">
                <div class="dt dsc-cm">网站导航<i class="iconfont icon-down"></i></div>
                <div class="dd dorpdown-layer">
                    <dl class="fore1">
                        <dt>特色主题</dt>
                        <dd>
                                                                                                <div class="item"><a href="category.php?id=858" target="_blank">家用电器</a></div>
                                                                                                                                <div class="item"><a href="category.php?id=3" target="_blank">手机数码</a></div>
                                                                                                                                <div class="item"><a href="category.php?id=4" target="_blank">电脑办公</a></div>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                </dd>
                    </dl>
                    <dl class="fore2">
                        <dt>促销活动</dt>
                        <dd>
                                                                                                                                                                                                                                                                                                                                                <div class="item"><a href="auction.php">拍卖活动</a></div>
                                                                                                                                <div class="item"><a href="crowdfunding.php">共创商品</a></div>
                                                                                                                                <div class="item"><a href="activity.php">优惠活动</a></div>
                                                                                                                                <div class="item"><a href="wholesale.php">批发市场</a></div>
                                                                                                                                <div class="item"><a href="package.php">超值礼包</a></div>
                                                                                                                                <div class="item"><a href="coupons.php?act=coupons_index">优惠券</a></div>
                                                                                                                                <div class="item"><a href="gift_gard.php">提货中心</a></div>
                                                                                    </dd>
                    </dl>
                </div>
            </li>
                    </ul>
    </div>
</div>
<div class="header">
    <div class="w w1200">
        <div class="logo">
            <div class="logoImg"><a href="index.php"><img src="../themes/ecmoban_dsc2017/images/logo.gif" /></a></div>
						<div class="logoAdv"><a href="merchants.php"><img src="themes/ecmoban_dsc2017/images/ecsc-join.gif" /></a></div>
			        </div>
        <div class="dsc-search">
            <div class="form">
                <form id="searchForm" name="searchForm" method="get" action="search.php" onSubmit="return checkSearchForm(this)" class="search-form">
                    <input autocomplete="off" onKeyUp="lookup(this.value);" name="keywords" type="text" id="keyword" value="554fcae493e564ee0dc75bdf2ebf94carand_keyword|a:1:{s:4:"name";s:12:"rand_keyword";}554fcae493e564ee0dc75bdf2ebf94ca" class="search-text"/>
                                        <input type="hidden" name="store_search_cmt" value="0">
                    <button type="submit" class="button button-goods" onclick="checkstore_search_cmt(0)">搜商品</button>
                    <button type="submit" class="button button-store" onclick="checkstore_search_cmt(1)">搜店铺</button>
                                    </form>
                                <ul class="keyword">
                                <li><a href="search.php?keywords=%E7%89%B9%E8%89%B2" target="_blank">特色</a></li>
                                <li><a href="search.php?keywords=%E7%89%B9%E4%BA%A7" target="_blank">特产</a></li>
                                <li><a href="search.php?keywords=%E7%A4%BC%E5%93%81" target="_blank">礼品</a></li>
                                <li><a href="search.php?keywords=%E7%BA%AA%E5%BF%B5%E5%93%81" target="_blank">纪念品</a></li>
                                <li><a href="search.php?keywords=%E7%BE%8E%E9%A3%9F" target="_blank">美食</a></li>
                                </ul>
                                
                <div class="suggestions_box" id="suggestions" style="display:none;">
                    <div class="suggestions_list" id="auto_suggestions_list">
                        &nbsp;
                    </div>
                </div>
                
            </div>
        </div>
        <div class="shopCart" data-ectype="dorpdown" id="ECS_CARTINFO" data-carteveval="0">
        554fcae493e564ee0dc75bdf2ebf94cacart_info|a:1:{s:4:"name";s:9:"cart_info";}554fcae493e564ee0dc75bdf2ebf94ca        </div>
    </div>
</div>
<div class="nav dsc-zoom" ectype="dscNav">
    <div class="w w1200">
        <div class="categorys site-mast">
            <div class="categorys-type"><a href="categoryall.php" target="_blank">全部商品分类</a></div>
            <div class="categorys-tab-content">
            	554fcae493e564ee0dc75bdf2ebf94cacategory_tree_nav|a:3:{s:4:"name";s:17:"category_tree_nav";s:9:"cat_model";s:1:"0";s:7:"cat_num";i:7;}554fcae493e564ee0dc75bdf2ebf94ca            </div>
        </div>
                <div class="nav-main" id="nav">
            <ul class="navitems">
                <li><a href="index.php" >首页</a></li>
                                <li><a href="category.php?id=12"  >食品特产</a></li>
                                <li><a href="category.php?id=6"  >服装城</a></li>
                                <li><a href="category.php?id=858"  >大家电</a></li>
                                <li><a href="category.php?id=8"  >鞋靴箱包</a></li>
                                <li><a href="brand.php"  >品牌专区</a></li>
                                <li><a href="group_buy.php"  >聚划算</a></li>
                                <li><a href="exchange.php"  >积分商城</a></li>
                                <li><a href="presale.php"  >预售</a></li>
                                <li><a href="store_street.php" class="curr" >店铺街</a></li>
                            </ul>
        </div>
            </div>
</div>
    <div class="content">
        <div class="banner street-banner">
            554fcae493e564ee0dc75bdf2ebf94caget_adv_child|a:2:{s:4:"name";s:13:"get_adv_child";s:6:"ad_arr";s:371:"'store_street_ad1,'store_street_ad2,'store_street_ad3,'store_street_ad4,'store_street_ad5,'store_street_ad6,'store_street_ad7,'store_street_ad8,'store_street_ad9,'store_street_ad10,'store_street_ad11,'store_street_ad12,'store_street_ad13,'store_street_ad14,'store_street_ad15,'store_street_ad16,'store_street_ad17,'store_street_ad18,'store_street_ad19,'store_street_ad20,";}554fcae493e564ee0dc75bdf2ebf94ca        </div>
        <div class="street-main">
            <div class="w w1200">
                <div class="selector gb-selector street-filter-wapper">
                                        <div class="s-line">
                        <div class="s-l-wrap">
                            <div class="s-l-tit"><span>分类：</span></div>
                            <div class="s-l-value">
                                <div class="s-l-v-list">
                                    <ul>
                                        <li class="curr"><a href="javascript:void(0);"  data-val="0" data-type="search_cat" data-region="6" ectype="street_area">全部</a></li>
                                                                                <li><a href="javascript:void(0);"  data-val="858" data-type="search_cat" data-region="6" ectype="street_area">家用电器</a></li>
                                                                                <li><a href="javascript:void(0);"  data-val="3" data-type="search_cat" data-region="6" ectype="street_area">手机数码</a></li>
                                                                                <li><a href="javascript:void(0);"  data-val="4" data-type="search_cat" data-region="6" ectype="street_area">电脑办公</a></li>
                                                                                <li><a href="javascript:void(0);"  data-val="5" data-type="search_cat" data-region="6" ectype="street_area">家居家纺</a></li>
                                                                                <li><a href="javascript:void(0);"  data-val="6" data-type="search_cat" data-region="6" ectype="street_area">男装女装</a></li>
                                                                                <li><a href="javascript:void(0);"  data-val="8" data-type="search_cat" data-region="6" ectype="street_area">鞋靴箱包</a></li>
                                                                                <li><a href="javascript:void(0);"  data-val="860" data-type="search_cat" data-region="6" ectype="street_area">个人化妆</a></li>
                                                                                <li><a href="javascript:void(0);"  data-val="11" data-type="search_cat" data-region="6" ectype="street_area">母婴玩具</a></li>
                                                                                <li><a href="javascript:void(0);"  data-val="1" data-type="search_cat" data-region="6" ectype="street_area">图书音像</a></li>
                                                                                <li><a href="javascript:void(0);"  data-val="866" data-type="search_cat" data-region="6" ectype="street_area">休闲运动</a></li>
                                                                                <li><a href="javascript:void(0);"  data-val="864" data-type="search_cat" data-region="6" ectype="street_area">腕表珠宝</a></li>
                                                                                <li><a href="javascript:void(0);"  data-val="861" data-type="search_cat" data-region="6" ectype="street_area">汽车汽配</a></li>
                                                                                <li><a href="javascript:void(0);"  data-val="12" data-type="search_cat" data-region="6" ectype="street_area">食品酒水</a></li>
                                                                                <li><a href="javascript:void(0);"  data-val="863" data-type="search_cat" data-region="6" ectype="street_area">保健器械</a></li>
                                                                                <li><a href="javascript:void(0);"  data-val="865" data-type="search_cat" data-region="6" ectype="street_area">营养滋补</a></li>
                                                                                <li><a href="javascript:void(0);"  data-val="867" data-type="search_cat" data-region="6" ectype="street_area">礼品卡券</a></li>
                                                                            </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                                                            <div class="s-line">
                        <div class="s-l-wrap">
                            <div class="s-l-tit"><span>省份：</span></div>
                            <div class="s-l-value">
                                <div class="s-l-v-list">
                                    <ul>
                                        <li class="curr"><a href="javascript:void(0);" data-val="0" data-type="search_city" data-region="1" ectype="street_area">全部</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="2" data-type="search_city" data-region="1" ectype="street_area" >北京</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="3" data-type="search_city" data-region="1" ectype="street_area" >安徽</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="4" data-type="search_city" data-region="1" ectype="street_area" >福建</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="5" data-type="search_city" data-region="1" ectype="street_area" >甘肃</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="6" data-type="search_city" data-region="1" ectype="street_area" >广东</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="7" data-type="search_city" data-region="1" ectype="street_area" >广西</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="8" data-type="search_city" data-region="1" ectype="street_area" >贵州</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="9" data-type="search_city" data-region="1" ectype="street_area" >海南</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="10" data-type="search_city" data-region="1" ectype="street_area" >河北</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="11" data-type="search_city" data-region="1" ectype="street_area" >河南</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="12" data-type="search_city" data-region="1" ectype="street_area" >黑龙江</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="13" data-type="search_city" data-region="1" ectype="street_area" >湖北</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="14" data-type="search_city" data-region="1" ectype="street_area" >湖南</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="15" data-type="search_city" data-region="1" ectype="street_area" >吉林</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="16" data-type="search_city" data-region="1" ectype="street_area" >江苏</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="17" data-type="search_city" data-region="1" ectype="street_area" >江西</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="18" data-type="search_city" data-region="1" ectype="street_area" >辽宁</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="19" data-type="search_city" data-region="1" ectype="street_area" >内蒙古</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="20" data-type="search_city" data-region="1" ectype="street_area" >宁夏</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="21" data-type="search_city" data-region="1" ectype="street_area" >青海</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="22" data-type="search_city" data-region="1" ectype="street_area" >山东</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="23" data-type="search_city" data-region="1" ectype="street_area" >山西</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="24" data-type="search_city" data-region="1" ectype="street_area" >陕西</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="25" data-type="search_city" data-region="1" ectype="street_area" >上海</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="26" data-type="search_city" data-region="1" ectype="street_area" >四川</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="27" data-type="search_city" data-region="1" ectype="street_area" >天津</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="28" data-type="search_city" data-region="1" ectype="street_area" >西藏</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="29" data-type="search_city" data-region="1" ectype="street_area" >新疆</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="30" data-type="search_city" data-region="1" ectype="street_area" >云南</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="31" data-type="search_city" data-region="1" ectype="street_area" >浙江</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="32" data-type="search_city" data-region="1" ectype="street_area" >重庆</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="33" data-type="search_city" data-region="1" ectype="street_area" >香港</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="34" data-type="search_city" data-region="1" ectype="street_area" >澳门</a></li>
                                                                                <li ><a href="javascript:void(0);" data-val="35" data-type="search_city" data-region="1" ectype="street_area" >台湾</a></li>
                                                                            </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="store_city"></div>
                    <div id="store_district"></div>
                                        <input name="store_user" id="res_store_user" value="" type="hidden" />
                    <input name="store_province" id="res_store_province" value="" type="hidden" />
                    <input name="store_city" id="res_store_city" value="" type="hidden" />
                    <input name="store_district" id="res_store_district" value="" type="hidden" />
                    <div class="s-line">
                        <div class="s-l-wrap">
                            <div class="s-l-tit"><span>排序方式：</span></div>
                            <div class="s-l-value">
                                <div class="mod-list-sort">
                                    <div class="sort-l">
                                        <!--<a href="javascript:void(0);" class="sort-item curr" ectype="seller_sort" data-sort='shop_id' data-order='DESC'>默认</a>-->
                                        <a href="javascript:void(0);" class="sort-item" ectype="seller_sort" data-sort='sort_order' data-order='DESC'>热门<i class="iconfont icon-up1"></i></a>
                                        <a href="javascript:void(0);" class="sort-item" ectype="seller_sort" data-sort='sales_volume' data-order='DESC'>销量<i class="iconfont icon-up1"></i></a>
                                        <a href="javascript:void(0);" class="sort-item" ectype="seller_sort" data-sort='store_score' data-order='DESC'>评分<i class="iconfont icon-up1"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="street-list" ectype="store_shop_list" id="store_shop_list">
					<div class="grid-sizer"></div>
<div class="gutter-sizer"></div>
<div class="street-list-item">
    <a href="merchants_store.php?merchant_id=18" target="_blank" class="cover"><img src="data/store_street/street_thumb/1490228594432338850.jpg" alt="Swisse专卖店"></a>
    <div class="info">
        <a href="javascript:void(0);" ectype="collect_store" data-value='{"userid":0,"storeid":18}' data-url="store_street.php" class="s-follow"><i class="iconfont icon-zan-alt"></i></a>
        <div class="s-logo"><a href="merchants_store.php?merchant_id=18" target="_blank"><img src="data/store_street/brand_thumb/1490228594628077151.jpg" alt="Swisse专卖店"></a></div>
        <div class="s-name"><a href="merchants_store.php?merchant_id=18" target="_blank" class="name">Swisse专卖店</a></div>
                <p>主营品牌： Swisse</p>
        <p>商家等级： <!--<span class="shop-level-icon level-1"></span>--><img src="data/seller_grade/1490317342721835143.png" title="普通商家" width="20"/></p>
    </div>
</div>
<div class="street-list-item">
    <a href="merchants_store.php?merchant_id=16" target="_blank" class="cover"><img src="data/store_street/street_thumb/1490228242535175941.jpg" alt="迪卡侬专卖店"></a>
    <div class="info">
        <a href="javascript:void(0);" ectype="collect_store" data-value='{"userid":0,"storeid":16}' data-url="store_street.php" class="s-follow"><i class="iconfont icon-zan-alt"></i></a>
        <div class="s-logo"><a href="merchants_store.php?merchant_id=16" target="_blank"><img src="data/store_street/brand_thumb/1490228242944564851.jpg" alt="迪卡侬专卖店"></a></div>
        <div class="s-name"><a href="merchants_store.php?merchant_id=16" target="_blank" class="name">迪卡侬专卖店</a></div>
                <p>主营品牌： 迪卡侬</p>
        <p>商家等级： <!--<span class="shop-level-icon level-1"></span>--><img src="data/seller_grade/1490317342721835143.png" title="普通商家" width="20"/></p>
    </div>
</div>
<div class="street-list-item">
    <a href="merchants_store.php?merchant_id=15" target="_blank" class="cover"><img src="data/store_street/street_thumb/1490226941202175586.jpg" alt="七匹狼旗舰店"></a>
    <div class="info">
        <a href="javascript:void(0);" ectype="collect_store" data-value='{"userid":0,"storeid":15}' data-url="store_street.php" class="s-follow"><i class="iconfont icon-zan-alt"></i></a>
        <div class="s-logo"><a href="merchants_store.php?merchant_id=15" target="_blank"><img src="data/store_street/brand_thumb/1490226941031650427.jpg" alt="七匹狼旗舰店"></a></div>
        <div class="s-name"><a href="merchants_store.php?merchant_id=15" target="_blank" class="name">七匹狼旗舰店</a></div>
                <p>主营品牌： 七匹狼</p>
        <p>商家等级： <!--<span class="shop-level-icon level-1"></span>--><img src="data/seller_grade/1490317342721835143.png" title="普通商家" width="20"/></p>
    </div>
</div>
<div class="street-list-item">
    <a href="merchants_store.php?merchant_id=14" target="_blank" class="cover"><img src="data/store_street/street_thumb/1490226529890141150.jpg" alt="周大福旗舰店"></a>
    <div class="info">
        <a href="javascript:void(0);" ectype="collect_store" data-value='{"userid":0,"storeid":14}' data-url="store_street.php" class="s-follow"><i class="iconfont icon-zan-alt"></i></a>
        <div class="s-logo"><a href="merchants_store.php?merchant_id=14" target="_blank"><img src="data/store_street/brand_thumb/1490226529449129290.jpg" alt="周大福旗舰店"></a></div>
        <div class="s-name"><a href="merchants_store.php?merchant_id=14" target="_blank" class="name">周大福旗舰店</a></div>
                <p>主营品牌： 周大福</p>
        <p>商家等级： <!--<span class="shop-level-icon level-1"></span>--><img src="data/seller_grade/1490317342721835143.png" title="普通商家" width="20"/></p>
    </div>
</div>
<div class="street-list-item">
    <a href="merchants_store.php?merchant_id=13" target="_blank" class="cover"><img src="data/store_street/street_thumb/1490226273037489622.jpg" alt="当当旗舰店旗舰店"></a>
    <div class="info">
        <a href="javascript:void(0);" ectype="collect_store" data-value='{"userid":0,"storeid":13}' data-url="store_street.php" class="s-follow"><i class="iconfont icon-zan-alt"></i></a>
        <div class="s-logo"><a href="merchants_store.php?merchant_id=13" target="_blank"><img src="data/store_street/brand_thumb/1490226273934518900.jpg" alt="当当旗舰店旗舰店"></a></div>
        <div class="s-name"><a href="merchants_store.php?merchant_id=13" target="_blank" class="name">当当旗舰店旗舰店</a></div>
                <p>主营品牌： 当当旗舰店</p>
        <p>商家等级： <!--<span class="shop-level-icon level-1"></span>--><img src="data/seller_grade/1490317342721835143.png" title="普通商家" width="20"/></p>
    </div>
</div>
<div class="street-list-item">
    <a href="merchants_store.php?merchant_id=12" target="_blank" class="cover"><img src="data/store_street/street_thumb/1490225921678391348.jpg" alt="大众专卖店"></a>
    <div class="info">
        <a href="javascript:void(0);" ectype="collect_store" data-value='{"userid":0,"storeid":12}' data-url="store_street.php" class="s-follow"><i class="iconfont icon-zan-alt"></i></a>
        <div class="s-logo"><a href="merchants_store.php?merchant_id=12" target="_blank"><img src="data/store_street/brand_thumb/1490225921672477419.jpg" alt="大众专卖店"></a></div>
        <div class="s-name"><a href="merchants_store.php?merchant_id=12" target="_blank" class="name">大众专卖店</a></div>
                <p>主营品牌： 大众</p>
        <p>商家等级： <!--<span class="shop-level-icon level-1"></span>--><img src="data/seller_grade/1490317342721835143.png" title="普通商家" width="20"/></p>
    </div>
</div>
<div class="street-list-item">
    <a href="merchants_store.php?merchant_id=11" target="_blank" class="cover"><img src="data/store_street/street_thumb/1490225353320446798.jpg" alt="多秒屋"></a>
    <div class="info">
        <a href="javascript:void(0);" ectype="collect_store" data-value='{"userid":0,"storeid":11}' data-url="store_street.php" class="s-follow"><i class="iconfont icon-zan-alt"></i></a>
        <div class="s-logo"><a href="merchants_store.php?merchant_id=11" target="_blank"><img src="data/store_street/brand_thumb/1490225353614557362.jpg" alt="多秒屋"></a></div>
        <div class="s-name"><a href="merchants_store.php?merchant_id=11" target="_blank" class="name">多秒屋</a></div>
                <p>主营品牌： 多秒屋</p>
        <p>商家等级： <!--<span class="shop-level-icon level-1"></span>--><img src="data/seller_grade/1490317342721835143.png" title="普通商家" width="20"/></p>
    </div>
</div>
<div class="street-list-item">
    <a href="merchants_store.php?merchant_id=10" target="_blank" class="cover"><img src="data/store_street/street_thumb/1490223410708601451.jpg" alt="成人旗舰店"></a>
    <div class="info">
        <a href="javascript:void(0);" ectype="collect_store" data-value='{"userid":0,"storeid":10}' data-url="store_street.php" class="s-follow"><i class="iconfont icon-zan-alt"></i></a>
        <div class="s-logo"><a href="merchants_store.php?merchant_id=10" target="_blank"><img src="data/store_street/brand_thumb/1490223410237633996.jpg" alt="成人旗舰店"></a></div>
        <div class="s-name"><a href="merchants_store.php?merchant_id=10" target="_blank" class="name">成人旗舰店</a></div>
                <p>主营品牌： 杜蕾斯</p>
        <p>商家等级： <!--<span class="shop-level-icon level-1"></span>--><img src="data/seller_grade/1490317342721835143.png" title="普通商家" width="20"/></p>
    </div>
</div>
<div class="street-list-item">
    <a href="merchants_store.php?merchant_id=9" target="_blank" class="cover"><img src="data/store_street/street_thumb/1490223011111438424.jpg" alt="美宝莲"></a>
    <div class="info">
        <a href="javascript:void(0);" ectype="collect_store" data-value='{"userid":0,"storeid":9}' data-url="store_street.php" class="s-follow"><i class="iconfont icon-zan-alt"></i></a>
        <div class="s-logo"><a href="merchants_store.php?merchant_id=9" target="_blank"><img src="data/store_street/brand_thumb/1490223011153110906.jpg" alt="美宝莲"></a></div>
        <div class="s-name"><a href="merchants_store.php?merchant_id=9" target="_blank" class="name">美宝莲</a></div>
                <p>主营品牌： 美宝莲</p>
        <p>商家等级： <!--<span class="shop-level-icon level-1"></span>--><img src="data/seller_grade/1490317342721835143.png" title="普通商家" width="20"/></p>
    </div>
</div>
<div class="street-list-item">
    <a href="merchants_store.php?merchant_id=6" target="_blank" class="cover"><img src="data/store_street/street_thumb/1490168617959840802.jpg" alt="服装专卖店"></a>
    <div class="info">
        <a href="javascript:void(0);" ectype="collect_store" data-value='{"userid":0,"storeid":6}' data-url="store_street.php" class="s-follow"><i class="iconfont icon-zan-alt"></i></a>
        <div class="s-logo"><a href="merchants_store.php?merchant_id=6" target="_blank"><img src="data/store_street/brand_thumb/1490168617360778777.jpg" alt="服装专卖店"></a></div>
        <div class="s-name"><a href="merchants_store.php?merchant_id=6" target="_blank" class="name">服装专卖店</a></div>
                <p>主营品牌： 服装</p>
        <p>商家等级： <!--<span class="shop-level-icon level-1"></span>--><img src="data/seller_grade/1490317342721835143.png" title="普通商家" width="20"/></p>
    </div>
</div>
<div class="street-list-item">
    <a href="merchants_store.php?merchant_id=5" target="_blank" class="cover"><img src="data/store_street/street_thumb/1490164131840670339.jpg" alt="三只松鼠"></a>
    <div class="info">
        <a href="javascript:void(0);" ectype="collect_store" data-value='{"userid":0,"storeid":5}' data-url="store_street.php" class="s-follow"><i class="iconfont icon-zan-alt"></i></a>
        <div class="s-logo"><a href="merchants_store.php?merchant_id=5" target="_blank"><img src="data/store_street/brand_thumb/1490164131868221887.jpg" alt="三只松鼠"></a></div>
        <div class="s-name"><a href="merchants_store.php?merchant_id=5" target="_blank" class="name">三只松鼠</a></div>
                <p>主营品牌： 三只松鼠</p>
        <p>商家等级： <!--<span class="shop-level-icon level-1"></span>--><img src="data/seller_grade/1490317342721835143.png" title="普通商家" width="20"/></p>
    </div>
</div>
<div class="street-list-item">
    <a href="merchants_store.php?merchant_id=4" target="_blank" class="cover"><img src="data/store_street/street_thumb/1490160857982584904.jpg" alt="全友家私"></a>
    <div class="info">
        <a href="javascript:void(0);" ectype="collect_store" data-value='{"userid":0,"storeid":4}' data-url="store_street.php" class="s-follow"><i class="iconfont icon-zan-alt"></i></a>
        <div class="s-logo"><a href="merchants_store.php?merchant_id=4" target="_blank"><img src="data/store_street/brand_thumb/1490160857716424359.jpg" alt="全友家私"></a></div>
        <div class="s-name"><a href="merchants_store.php?merchant_id=4" target="_blank" class="name">全友家私</a></div>
                <p>主营品牌： 全友家私</p>
        <p>商家等级： <!--<span class="shop-level-icon level-1"></span>--><img src="data/seller_grade/1490317359889476055.png" title="金牌商家" width="20"/></p>
    </div>
</div>
<div class="street-list-item">
    <a href="merchants_store.php?merchant_id=3" target="_blank" class="cover"><img src="data/store_street/street_thumb/1490159042324590344.jpg" alt="火影旗舰店"></a>
    <div class="info">
        <a href="javascript:void(0);" ectype="collect_store" data-value='{"userid":0,"storeid":3}' data-url="store_street.php" class="s-follow"><i class="iconfont icon-zan-alt"></i></a>
        <div class="s-logo"><a href="merchants_store.php?merchant_id=3" target="_blank"><img src="data/store_street/brand_thumb/1490159042003546514.jpg" alt="火影旗舰店"></a></div>
        <div class="s-name"><a href="merchants_store.php?merchant_id=3" target="_blank" class="name">火影旗舰店</a></div>
                <p>主营品牌： 火影</p>
        <p>商家等级： <!--<span class="shop-level-icon level-1"></span>--><img src="data/seller_grade/1490317359889476055.png" title="金牌商家" width="20"/></p>
    </div>
</div>
<div class="street-list-item">
    <a href="merchants_store.php?merchant_id=2" target="_blank" class="cover"><img src="data/store_street/street_thumb/1490153973561051484.jpg" alt="绿联专卖店"></a>
    <div class="info">
        <a href="javascript:void(0);" ectype="collect_store" data-value='{"userid":0,"storeid":2}' data-url="store_street.php" class="s-follow"><i class="iconfont icon-zan-alt"></i></a>
        <div class="s-logo"><a href="merchants_store.php?merchant_id=2" target="_blank"><img src="data/store_street/brand_thumb/1490915977483540879.jpg" alt="绿联专卖店"></a></div>
        <div class="s-name"><a href="merchants_store.php?merchant_id=2" target="_blank" class="name">绿联专卖店</a></div>
                <p>主营品牌： 绿联</p>
        <p>商家等级： <!--<span class="shop-level-icon level-1"></span>--><img src="data/seller_grade/1490317359889476055.png" title="金牌商家" width="20"/></p>
    </div>
</div>
<div class="street-list-item">
    <a href="merchants_store.php?merchant_id=1" target="_blank" class="cover"><img src="data/store_street/street_thumb/1490146939166715823.jpg" alt="万卓旗舰店"></a>
    <div class="info">
        <a href="javascript:void(0);" ectype="collect_store" data-value='{"userid":0,"storeid":1}' data-url="store_street.php" class="s-follow"><i class="iconfont icon-zan-alt"></i></a>
        <div class="s-logo"><a href="merchants_store.php?merchant_id=1" target="_blank"><img src="data/store_street/brand_thumb/1490146939419384134.jpg" alt="万卓旗舰店"></a></div>
        <div class="s-name"><a href="merchants_store.php?merchant_id=1" target="_blank" class="name">万卓旗舰店</a></div>
                <p>主营品牌： 万卓</p>
        <p>商家等级： <!--<span class="shop-level-icon level-1"></span>--><img src="data/seller_grade/1490317359889476055.png" title="金牌商家" width="20"/></p>
    </div>
</div>
                </div>
                <div class="sellerlist" ectype="pages_ajax" id="pages_ajax">
                	                </div>
            </div>
        </div>
    </div>
    <input name="area_list" value="" type="hidden" />
    <input name="user_id" value="0" type="hidden" />
    554fcae493e564ee0dc75bdf2ebf94causer_menu_position|a:1:{s:4:"name";s:18:"user_menu_position";}554fcae493e564ee0dc75bdf2ebf94ca
    <div class="footer-new">
    <div class="footer-new-top">
    	<div class="w w1200">
            <div class="service-list">
                <div class="service-item">
                    <i class="f-icon f-icon-qi"></i>
                    <span>七天包退</span>
                </div>
                <div class="service-item">
                    <i class="f-icon f-icon-zheng"></i>
                    <span>正品保障</span>
                </div>
                <div class="service-item">
                    <i class="f-icon f-icon-hao"></i>
                    <span>好评如潮</span>
                </div>
                <div class="service-item">
                    <i class="f-icon f-icon-shan"></i>
                    <span>闪电发货</span>
                </div>
                <div class="service-item">
                    <i class="f-icon f-icon-quan"></i>
                    <span>权威荣誉</span>
                </div>
            </div>
            <div class="contact">
                <div class="contact-item contact-item-first"><i class="f-icon f-icon-tel"></i><span>027-87158232</span></div>
                <div class="contact-item">
                	                    <a id="IM" IM_type="dsc" onclick="openWin(this)" href="javascript:;" class="btn-ctn"><i class="f-icon f-icon-kefu"></i><span>咨询客服</span></a>
                                    </div>
            </div>
        </div>
    </div>
    <div class="footer-new-con">
    	<div class="fnc-warp">
            <div class="help-list">
                                                <div class="help-item">
                    <h3>配送与支付 </h3>
                    <ul>
                                                            <li><a href="article.php?id=55"  title="上门自提" target="_blank">上门自提</a></li>
                                                                                <li><a href="article.php?id=17"  title="支付方式说明" target="_blank">支付方式说明</a></li>
                                                                                <li><a href="article.php?id=16"  title="配送支付智能查询 " target="_blank">配送支付智能查询</a></li>
                                                                                                    </ul>
                </dl>
                </div>
                                                                <div class="help-item">
                    <h3>新手上路 </h3>
                    <ul>
                                                            <li><a href="article.php?id=36"  title="隐私声明" target="_blank">隐私声明</a></li>
                                                                                <li><a href="article.php?id=11"  title="订购方式" target="_blank">订购方式</a></li>
                                                                                <li><a href="article.php?id=10"  title="购物流程" target="_blank">购物流程</a></li>
                                                                                                    </ul>
                </dl>
                </div>
                                                                <div class="help-item">
                    <h3>联系我们 </h3>
                    <ul>
                                                            <li><a href="article.php?id=26"  title="投诉与建议 " target="_blank">投诉与建议</a></li>
                                                                                <li><a href="article.php?id=25"  title="选机咨询 " target="_blank">选机咨询</a></li>
                                                                                <li><a href="article.php?id=24"  title="网站故障报告" target="_blank">网站故障报告</a></li>
                                                            </ul>
                </dl>
                </div>
                                                                <div class="help-item">
                    <h3>服务保证 </h3>
                    <ul>
                                                            <li><a href="article.php?id=23"  title="产品质量保证 " target="_blank">产品质量保证</a></li>
                                                                                <li><a href="article.php?id=22"  title="售后服务保证" target="_blank">售后服务保证</a></li>
                                                                                <li><a href="article.php?id=21"  title="退换货原则" target="_blank">退换货原则</a></li>
                                                            </ul>
                </dl>
                </div>
                                                                <div class="help-item">
                    <h3>会员中心</h3>
                    <ul>
                                                            <li><a href="article.php?id=20"  title="我的订单" target="_blank">我的订单</a></li>
                                                                                <li><a href="article.php?id=19"  title="我的收藏" target="_blank">我的收藏</a></li>
                                                                                <li><a href="article.php?id=18"  title="资金管理" target="_blank">资金管理</a></li>
                                                            </ul>
                </dl>
                </div>
                                  
            </div>
            <div class="qr-code">
                <div class="qr-item qr-item-first">
                    <div class="code_img"><img src="images/common/ecjia_qrcode.png"></div>
                    <div class="code_txt">微信公众号</div>
                </div>
                <div class="qr-item">
                    <div class="code_img"><img src="images/common/ectouch_qrcode.png"></div>
                    <div class="code_txt">商城移动端</div>
                </div>
            </div>
    	</div>
    </div>
    <div class="footer-new-bot">
    	<div class="w w1200">
             
            <p class="copyright_links">
                                <a href="index.php">首页</a>
                 
                <span class="spacer"></span>
                 
                                <a href="article.php?id=2">隐私保护</a>
                 
                <span class="spacer"></span>
                 
                                <a href="article.php?id=4">联系我们</a>
                 
                <span class="spacer"></span>
                 
                                <a href="article.php?id=1">免责条款</a>
                 
                <span class="spacer"></span>
                 
                                <a href="article.php?id=5">公司简介</a>
                 
                <span class="spacer"></span>
                 
                                <a href="merchants.php" target="_blank" >商家入驻</a>
                 
                <span class="spacer"></span>
                 
                                <a href="message.php">意见反馈</a>
                 
                 
            </p>
                        
                        <p class="copyright_links">
                                    
                                                    <a href="http://www.jabrielcloud.com" target="_blank" title="加布里埃尔">加布里埃尔</a>
                                                                </p>
                        
                        <p><span>©&nbsp;2015-2018&nbsp; jabrielcloud.com&nbsp;版权所有&nbsp;&nbsp;</span><span>ICP备案证书号:</span><a href="http://www.miit.gov.cn/" target="_blank">鄂ICP备19029458号-1</a>&nbsp;POWERED by<a href="http://www.jabrielcloud.com/" target="_blank">文旅新零售平台</a>2.0</p>
                        
                        <p class="copyright_auth">&nbsp;</p>
                        
                    </div>
    </div>
    
    
    <div class="hide" id="pd_coupons">
        <span class="success-icon m-icon"></span>
        <div class="item-fore">
            <h3>领取成功！感谢您的参与，祝您购物愉快~</h3>
            <div class="txt ftx-03">本活动为概率性事件，不能保证所有客户成功领取优惠券</div>
        </div>
    </div>
    
    
    <div class="hidden">
        <input type="hidden" name="seller_kf_IM" value="" rev="" ru_id="0" />
        <input type="hidden" name="seller_kf_qq" value="82542370" />
        <input type="hidden" name="seller_kf_tel" value="027-87158232" />
        <input type="hidden" name="user_id" ectype="user_id" value="0" />
    </div>
</div>
<script type="text/javascript" src="js/suggest.js"></script><script type="text/javascript" src="js/scroll_city.js"></script><script type="text/javascript" src="js/utils.js"></script>
<script type="text/javascript" src="js/warehouse.js"></script><script type="text/javascript" src="js/warehouse_area.js"></script>
    
    <script type="text/javascript" src="js/jquery.SuperSlide.2.1.1.js"></script><script type="text/javascript" src="js/common.js"></script><script type="text/javascript" src="js/cart_common.js"></script><script type="text/javascript" src="js/parabola.js"></script><script type="text/javascript" src="js/shopping_flow.js"></script><script type="text/javascript" src="js/cart_quick_links.js"></script>	<script type="text/javascript" src="themes/ecmoban_dsc2017/js/dsc-common.js"></script>
    <script type="text/javascript" src="themes/ecmoban_dsc2017/js/jquery.purebox.js"></script>
    <script type="text/javascript" src="themes/ecmoban_dsc2017/js/masonry.pkgd.min.js"></script>
    <script type="text/javascript" src="themes/ecmoban_dsc2017/js/imagesloaded.pkgd.js"></script>
    <script type="text/javascript">
        function street(){
			$('.street-list').masonry('destroy');
			
			var masonryOptions = {
				columWidth: '.grid-sizer',
				gutter: '.gutter-sizer',
				itemSelector: '.street-list-item',
				percentPosition: true
			}
			
			var $grid = $('.street-list').masonry( masonryOptions );
			$grid.imagesLoaded().progress(function() {
				$grid.masonry();
			});
		}
		street();
    </script>
</body>
</html>